import React, { useState } from "react";
import { ALPHABET_SCRIPTS } from "../data/alphabets";
import { MASTER_VOCABULARY } from "../data/vocab";
import { SUPPORTED_LANGUAGES } from "../data/languages";
import { speakText } from "../utils/speech";
import { CustomWord } from "../types";
import { getCustomWords, addCustomWord, removeCustomWord } from "../utils/storage";
import {
  BookOpen,
  Volume2,
  Mic,
  Plus,
  Trash2,
  CheckCircle,
  AlertCircle,
  Sparkles,
  Layers,
  Award,
  Search
} from "lucide-react";

interface LearnScreenProps {
  targetLang: string;
}

export const LearnScreen: React.FC<LearnScreenProps> = ({ targetLang }) => {
  const [subTab, setSubTab] = useState<"script" | "vocab" | "practice">("script");
  const [selectedScriptLang, setSelectedScriptLang] = useState<string>("Hindi");

  // Custom Word State
  const [customWords, setCustomWords] = useState<CustomWord[]>(() => getCustomWords());
  const [showAddWordModal, setShowAddWordModal] = useState(false);
  const [newEnglish, setNewEnglish] = useState("");
  const [newTranslated, setNewTranslated] = useState("");

  // Pronunciation Practice State
  const [practiceTargetIndex, setPracticeTargetIndex] = useState(0);
  const [heardText, setHeardText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [analysisReport, setAnalysisReport] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const currentScriptGroup =
    ALPHABET_SCRIPTS.find((s) => s.language === selectedScriptLang) || ALPHABET_SCRIPTS[0];

  const targetLangSpeechTag =
    SUPPORTED_LANGUAGES.find((l) => l.name === targetLang)?.speechTag || "hi-IN";

  // Handle adding custom word
  const handleAddWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEnglish.trim()) return;

    const word: CustomWord = {
      english: newEnglish.trim(),
      language: targetLang,
      translated: newTranslated.trim() || newEnglish.trim(),
    };

    if (addCustomWord(word)) {
      setCustomWords(getCustomWords());
      setNewEnglish("");
      setNewTranslated("");
      setShowAddWordModal(false);
    } else {
      alert("Word already exists or is invalid!");
    }
  };

  const handleRemoveWord = (english: string) => {
    removeCustomWord(targetLang, english);
    setCustomWords(getCustomWords());
  };

  // Practice Pronunciation Action
  const handleAnalyzePronunciation = async (targetWord: string, heard: string) => {
    if (!heard.trim()) return;
    setIsAnalyzing(true);
    try {
      const res = await fetch("/api/analyze-pronunciation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetWord,
          heardText: heard,
          language: targetLang,
        }),
      });
      const data = await res.json();
      setAnalysisReport(data);
    } catch (err) {
      console.error("Pronunciation analysis error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const currentPracticeWord =
    MASTER_VOCABULARY[practiceTargetIndex % MASTER_VOCABULARY.length];
  const currentTargetTranslation =
    currentPracticeWord.translations[targetLang] || currentPracticeWord.english;

  return (
    <div className="pb-24 pt-4 px-4 max-w-3xl mx-auto space-y-5">
      {/* Learn Header Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-3xl p-5 shadow-xl flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            Language Studio
          </h1>
          <p className="text-xs text-indigo-200/80 mt-1">
            Master alphabets, vocabulary & akshara-level pronunciation for{" "}
            <span className="text-amber-300 font-bold">{targetLang}</span>
          </p>
        </div>
        <button
          onClick={() => setShowAddWordModal(true)}
          className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-lg flex items-center gap-1.5 shrink-0"
          id="btn-add-custom-word"
        >
          <Plus className="w-4 h-4" /> Add Word
        </button>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 gap-1">
        <button
          onClick={() => setSubTab("script")}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === "script"
              ? "bg-indigo-600 text-white shadow-md"
              : "text-slate-400 hover:text-slate-200"
          }`}
          id="tab-learn-script"
        >
          <Layers className="w-4 h-4" />
          Alphabets & Scripts
        </button>
        <button
          onClick={() => setSubTab("vocab")}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === "vocab"
              ? "bg-indigo-600 text-white shadow-md"
              : "text-slate-400 hover:text-slate-200"
          }`}
          id="tab-learn-vocab"
        >
          <BookOpen className="w-4 h-4" />
          Vocabulary
        </button>
        <button
          onClick={() => setSubTab("practice")}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === "practice"
              ? "bg-indigo-600 text-white shadow-md"
              : "text-slate-400 hover:text-slate-200"
          }`}
          id="tab-learn-practice"
        >
          <Mic className="w-4 h-4" />
          Pronunciation Coach
        </button>
      </div>

      {/* TAB 1: ALPHABETS & SCRIPTS */}
      {subTab === "script" && (
        <div className="space-y-4">
          {/* Script Selector */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {ALPHABET_SCRIPTS.map((script) => (
              <button
                key={script.language}
                onClick={() => setSelectedScriptLang(script.language)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition border ${
                  selectedScriptLang === script.language
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                    : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
                }`}
              >
                {script.language} Script
              </button>
            ))}
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
            <h2 className="text-base font-bold text-white">{currentScriptGroup.scriptName}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{currentScriptGroup.description}</p>
          </div>

          {/* Letter Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {currentScriptGroup.letters.map((item, idx) => (
              <button
                key={idx}
                onClick={() => speakText(item.letter, targetLangSpeechTag)}
                className="bg-slate-900/90 hover:bg-indigo-950/50 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-3 text-left transition group relative overflow-hidden shadow-md"
              >
                <div className="flex items-center justify-between">
                  <span className="text-3xl font-black text-indigo-300 group-hover:scale-110 transition-transform">
                    {item.letter}
                  </span>
                  <Volume2 className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition" />
                </div>

                <p className="text-xs font-bold text-slate-200 mt-2">"{item.name}"</p>
                <p className="text-[11px] text-slate-400 leading-tight line-clamp-1">
                  {item.sound}
                </p>

                <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500">
                  <span className="font-semibold text-slate-300">{item.exampleWord}</span>
                  <span>{item.exampleTranslation}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: VOCABULARY LIST */}
      {subTab === "vocab" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-300 uppercase tracking-wider">
              Essential Vocabulary ({MASTER_VOCABULARY.length} Words)
            </h2>
          </div>

          {/* Custom Added Words Section */}
          {customWords.length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                My Custom Added Words
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {customWords.map((cw, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-200">{cw.english}</p>
                      <p className="text-xs text-indigo-300">{cw.translated}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => speakText(cw.translated, targetLangSpeechTag)}
                        className="p-1.5 rounded-lg bg-indigo-600/30 text-indigo-300 hover:bg-indigo-600/50"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleRemoveWord(cw.english)}
                        className="p-1.5 rounded-lg bg-rose-600/20 text-rose-400 hover:bg-rose-600/40"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Master Vocab Grid */}
          <div className="space-y-2">
            {MASTER_VOCABULARY.map((v) => {
              const translation = v.translations[targetLang] || v.english;
              return (
                <div
                  key={v.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between shadow-md hover:border-slate-700 transition"
                >
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                      {v.category}
                    </span>
                    <h3 className="text-sm font-bold text-white">{v.english}</h3>
                    <p className="text-xs font-semibold text-indigo-300">{translation}</p>
                  </div>
                  <button
                    onClick={() => speakText(translation, targetLangSpeechTag)}
                    className="p-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 hover:text-white transition border border-indigo-500/30"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: PRONUNCIATION COACH */}
      {subTab === "practice" && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-center space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/20 px-2.5 py-1 rounded-full border border-indigo-500/30">
              Akshara / Syllable Practice
            </span>

            <div className="py-3">
              <p className="text-xs text-slate-400">Word to speak in {targetLang}:</p>
              <h2 className="text-2xl font-black text-white mt-1">{currentTargetTranslation}</h2>
              <p className="text-xs text-indigo-300 font-medium">({currentPracticeWord.english})</p>
            </div>

            <button
              onClick={() => speakText(currentTargetTranslation, targetLangSpeechTag)}
              className="px-4 py-2 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs font-bold transition inline-flex items-center gap-1.5"
            >
              <Volume2 className="w-4 h-4" /> Hear Target Pronunciation
            </button>

            {/* Test Input */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <p className="text-xs text-slate-400">Type what you said or test recognition:</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={heardText}
                  onChange={(e) => setHeardText(e.target.value)}
                  placeholder={`Type or speak target word in ${targetLang}...`}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none w-full"
                />
                <button
                  onClick={() =>
                    handleAnalyzePronunciation(currentTargetTranslation, heardText)
                  }
                  disabled={!heardText.trim() || isAnalyzing}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition disabled:opacity-40"
                >
                  {isAnalyzing ? "Analyzing..." : "Analyze"}
                </button>
              </div>
            </div>

            {/* Next Practice Word */}
            <button
              onClick={() => {
                setPracticeTargetIndex((prev) => prev + 1);
                setHeardText("");
                setAnalysisReport(null);
              }}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-bold underline pt-2 block mx-auto"
            >
              Skip to Next Word →
            </button>
          </div>

          {/* Analysis Report Feedback */}
          {analysisReport && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-slate-300">
                  Pronunciation Feedback Score:
                </span>
                <span
                  className={`text-sm font-black ${
                    analysisReport.isMatch ? "text-emerald-400" : "text-amber-400"
                  }`}
                >
                  {analysisReport.score}%
                </span>
              </div>

              {analysisReport.headline && (
                <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-500/30 flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-indigo-200 font-medium leading-relaxed">
                    {analysisReport.headline}
                  </p>
                </div>
              )}

              {/* Syllable Breakdown */}
              {analysisReport.syllables && (
                <div className="space-y-1.5">
                  <p className="text-[10px] font-bold uppercase text-slate-400">
                    Syllable Breakdown:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {analysisReport.syllables.map((s: any, idx: number) => (
                      <div
                        key={idx}
                        className={`p-2 rounded-xl border text-xs ${
                          s.correct
                            ? "bg-emerald-950/40 border-emerald-500/30 text-emerald-300"
                            : "bg-rose-950/40 border-rose-500/30 text-rose-300"
                        }`}
                      >
                        <span className="font-bold">{s.expected}</span>
                        {s.heard && s.heard !== s.expected && (
                          <span className="text-[10px] opacity-80 block">Said: "{s.heard}"</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ADD CUSTOM WORD MODAL */}
      {showAddWordModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Add Word to {targetLang}</h3>
            <form onSubmit={handleAddWord} className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">English Word</label>
                <input
                  type="text"
                  required
                  value={newEnglish}
                  onChange={(e) => setNewEnglish(e.target.value)}
                  placeholder="e.g. Butterfly"
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none w-full"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  Translation in {targetLang}
                </label>
                <input
                  type="text"
                  value={newTranslated}
                  onChange={(e) => setNewTranslated(e.target.value)}
                  placeholder={`e.g. translation in ${targetLang}`}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none w-full"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddWordModal(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
                >
                  Save Word
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
