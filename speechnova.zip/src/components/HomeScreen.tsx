import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Language, TranslationMessage, AppSettings } from "../types";
import { SUPPORTED_LANGUAGES, SOURCE_LANGUAGES, AUTO_DETECT_LANGUAGE } from "../data/languages";
import { speakText, stopSpeech, createSpeechRecognizer } from "../utils/speech";
import { translateOffline, translateOfflineAsync, initIndexedDBDictionary, sampleAndDetectLanguage } from "../utils/offlineTranslator";
import { getDictionaryCount } from "../utils/indexedDB";
import { toggleFavorite } from "../utils/storage";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  ArrowRightLeft,
  Copy,
  Star,
  Share2,
  RotateCcw,
  Trash2,
  Sparkles,
  Send,
  Check,
  Globe,
  WifiOff,
  Smartphone,
  GraduationCap,
  FileText,
  Zap,
  Gauge
} from "lucide-react";

interface HomeScreenProps {
  messages: TranslationMessage[];
  onNewTranslation: (msg: TranslationMessage) => void;
  onClearHistory: () => void;
  onToggleFavorite: (msg: TranslationMessage) => void;
  sourceLang: string;
  setSourceLang: (lang: string) => void;
  targetLang: string;
  setTargetLang: (lang: string) => void;
  settings?: AppSettings;
  onOpenLectureModal?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  messages,
  onNewTranslation,
  onClearHistory,
  onToggleFavorite,
  sourceLang,
  setSourceLang,
  targetLang,
  setTargetLang,
  settings,
  onOpenLectureModal,
}) => {
  const [inputText, setInputText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isPlayingId, setIsPlayingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [detectedLangName, setDetectedLangName] = useState<string | null>(null);
  const [idbStats, setIdbStats] = useState<{ dictionaryCount: number; cacheCount: number }>({
    dictionaryCount: 0,
    cacheCount: 0,
  });

  const recognizerRef = useRef<any>(null);

  useEffect(() => {
    // Initialize IndexedDB offline dictionary and query stats
    initIndexedDBDictionary()
      .then(() => getDictionaryCount())
      .then((stats) => setIdbStats(stats))
      .catch((e) => console.warn("IndexedDB init warning:", e));
  }, []);

  const sourceLangObj =
    SOURCE_LANGUAGES.find((l) => l.name === sourceLang) || AUTO_DETECT_LANGUAGE;
  const targetLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.name === targetLang) || SUPPORTED_LANGUAGES[1];

  // Swap languages
  const handleSwap = () => {
    if (sourceLang === "Auto Detect") {
      setSourceLang(targetLang);
      setTargetLang("English");
    } else {
      const temp = sourceLang;
      setSourceLang(targetLang);
      setTargetLang(temp);
    }
  };

  // Perform Translation
  const handleTranslateText = async (textToTranslate: string) => {
    if (!textToTranslate.trim()) return;
    setIsTranslating(true);
    const startMs = performance.now();

    const isClientOffline = typeof navigator !== "undefined" && navigator.onLine === false;

    if (isClientOffline) {
      // Direct IndexedDB-backed client-side offline translation
      const offlineRes = await translateOfflineAsync(textToTranslate, sourceLang, targetLang);
      const latencyMs = Math.max(1, Math.round(performance.now() - startMs));
      setDetectedLangName(offlineRes.detectedLanguage);

      const inferredSource = sourceLang === "Auto Detect"
        ? `${offlineRes.detectedLanguage} (Offline Auto)`
        : `${sourceLang} (Offline)`;

      const newMsg: TranslationMessage = {
        id: Date.now().toString(),
        sourceText: textToTranslate,
        translatedText: offlineRes.translatedText,
        sourceLang: inferredSource,
        targetLang: targetLang,
        timestamp: Date.now(),
        romanization: offlineRes.romanization || "",
        latencyMs: latencyMs,
      };

      onNewTranslation(newMsg);
      setInputText("");
      handlePlaySpeech(newMsg.id, newMsg.translatedText, targetLangObj.speechTag, settings?.speechSpeed);
      setIsTranslating(false);
      // Refresh stats
      getDictionaryCount().then(setIdbStats);
      return;
    }

    try {
      const res = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: textToTranslate,
          sourceLang,
          targetLang,
          romanticTone: settings?.romanticTone,
        }),
      });

      const data = await res.json();
      const latencyMs = Math.max(1, Math.round(performance.now() - startMs));
      const detectedName = data.detectedLanguage || null;
      if (detectedName) {
        setDetectedLangName(detectedName);
      }

      const inferredSource = sourceLang === "Auto Detect"
        ? (detectedName ? `${detectedName} (Auto)` : "Auto Detected")
        : sourceLang;

      const newMsg: TranslationMessage = {
        id: Date.now().toString(),
        sourceText: textToTranslate,
        translatedText: data.translatedText || textToTranslate,
        sourceLang: inferredSource,
        targetLang: targetLang,
        timestamp: Date.now(),
        romanization: data.romanization || "",
        latencyMs: latencyMs,
      };

      onNewTranslation(newMsg);
      setInputText("");

      // Play audio automatically for target language using speech speed setting
      handlePlaySpeech(newMsg.id, newMsg.translatedText, targetLangObj.speechTag, settings?.speechSpeed);
    } catch (err) {
      console.warn("Server translation endpoint failed or offline, falling back to IndexedDB local translator:", err);
      const offlineRes = await translateOfflineAsync(textToTranslate, sourceLang, targetLang);
      const latencyMs = Math.max(1, Math.round(performance.now() - startMs));
      setDetectedLangName(offlineRes.detectedLanguage);

      const newMsg: TranslationMessage = {
        id: Date.now().toString(),
        sourceText: textToTranslate,
        translatedText: offlineRes.translatedText,
        sourceLang: sourceLang === "Auto Detect" ? `${offlineRes.detectedLanguage} (Auto)` : sourceLang,
        targetLang: targetLang,
        timestamp: Date.now(),
        romanization: offlineRes.romanization || "",
        latencyMs: latencyMs,
      };

      onNewTranslation(newMsg);
      setInputText("");
      handlePlaySpeech(newMsg.id, newMsg.translatedText, targetLangObj.speechTag, settings?.speechSpeed);
    } finally {
      setIsTranslating(false);
      getDictionaryCount().then(setIdbStats);
    }
  };

  // Speech Recognition toggle
  const toggleListening = () => {
    if (isListening) {
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setIsListening(false);
    } else {
      const speechTagToUse = sourceLang === "Auto Detect"
        ? (typeof navigator !== "undefined" && navigator.language ? navigator.language : "en-US")
        : sourceLangObj.speechTag;

      const recognizer = createSpeechRecognizer(speechTagToUse, {
        onResult: (transcript, isFinal) => {
          setInputText(transcript);
          if (sourceLang === "Auto Detect" && transcript.trim()) {
            const sampled = sampleAndDetectLanguage(transcript);
            setDetectedLangName(sampled.language);
          }
          if (isFinal) {
            setIsListening(false);
            handleTranslateText(transcript);
          }
        },
        onError: (err) => {
          console.warn("Speech recognition error:", err);
          setIsListening(false);
        },
        onEnd: () => {
          setIsListening(false);
        },
      });

      if (recognizer) {
        recognizerRef.current = recognizer;
        try {
          recognizer.start();
          setIsListening(true);
        } catch (e) {
          console.error("Failed to start recognizer:", e);
        }
      } else {
        alert("Speech Recognition is not supported in this browser. Please type or paste your text instead!");
      }
    }
  };

  // TTS Playback
  const handlePlaySpeech = (id: string, text: string, langTag: string, speedOverride?: number) => {
    if (isPlayingId === id) {
      stopSpeech();
      setIsPlayingId(null);
    } else {
      setIsPlayingId(id);
      const effectiveSpeed = speedOverride !== undefined ? speedOverride : settings?.speechSpeed;
      speakText(text, langTag, () => {
        setIsPlayingId(null);
      }, effectiveSpeed);
    }
  };

  // Copy to clipboard
  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-3xl mx-auto space-y-5">
      {/* Offline Storage Status Badge */}
      <div className="flex items-center justify-between bg-slate-900/60 border border-slate-800/80 rounded-2xl px-3.5 py-2 text-xs text-slate-400 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-medium text-slate-300">
            Offline Translation Ready
          </span>
        </div>
        <div className="text-[11px] font-bold text-indigo-300 bg-indigo-950/60 border border-indigo-500/20 px-2.5 py-0.5 rounded-lg">
          {idbStats.dictionaryCount > 0 ? `${idbStats.dictionaryCount} words loaded` : "On-Device Engine"}
        </div>
      </div>

      {/* Language Selector Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-xl flex items-center justify-between gap-2">
        {/* Source Language Dropdown */}
        <div className="flex-1 min-w-0">
          <label className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 block mb-1">
            From Language
          </label>
          <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-800 rounded-xl px-2.5 py-1.5">
            <span className="text-lg">{sourceLangObj.flag}</span>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value)}
              className="bg-transparent text-sm font-semibold text-white focus:outline-none w-full cursor-pointer"
              id="select-source-language"
            >
              {SOURCE_LANGUAGES.map((l) => (
                <option key={l.name} value={l.name} className="bg-slate-900 text-white">
                  {l.flag} {l.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Swap Button */}
        <button
          onClick={handleSwap}
          className="mt-4 p-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 border border-indigo-500/30 text-indigo-300 hover:text-white transition shadow-sm"
          title="Swap Languages"
          id="btn-swap-languages"
        >
          <ArrowRightLeft className="w-4 h-4" />
        </button>

        {/* Target Language Dropdown */}
        <div className="flex-1 min-w-0">
          <label className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 block mb-1">
            To Language
          </label>
          <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-800 rounded-xl px-2.5 py-1.5">
            <span className="text-lg">{targetLangObj.flag}</span>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value)}
              className="bg-transparent text-sm font-semibold text-white focus:outline-none w-full cursor-pointer"
              id="select-target-language"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.name} value={l.name} className="bg-slate-900 text-white">
                  {l.flag} {l.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Microphone Action Card */}
      <div className="bg-gradient-to-b from-slate-900 via-slate-900/90 to-indigo-950/40 border border-slate-800/80 rounded-3xl p-6 text-center shadow-2xl relative overflow-hidden">
        {/* Ambient background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <p className="text-xs font-medium text-slate-400 mb-2 flex items-center justify-center gap-1.5">
          <Globe className="w-3.5 h-3.5 text-indigo-400" />
          Translating <span className="text-indigo-300 font-bold">{sourceLang}</span> to{" "}
          <span className="text-indigo-300 font-bold">{targetLang}</span>
        </p>

        {sourceLang === "Auto Detect" && (
          <div className="inline-flex items-center gap-1.5 text-[11px] text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-3 py-1 rounded-full mb-3 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>
              {detectedLangName
                ? `Inferred Source: ${detectedLangName}`
                : `Smart Auto-Detect Language Active`}
            </span>
          </div>
        )}

        {/* Microphone Button */}
        <div className="relative inline-block my-2">
          {isListening && (
            <span className="absolute -inset-3 rounded-full bg-indigo-500/30 animate-ping" />
          )}
          <button
            onClick={toggleListening}
            className={`w-24 h-24 sm:w-28 sm:h-28 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl border ${
              isListening
                ? "bg-rose-600 border-rose-400 text-white shadow-rose-600/50 scale-105"
                : "bg-gradient-to-tr from-indigo-600 to-purple-600 border-indigo-400/50 text-white hover:scale-105 shadow-indigo-600/40"
            }`}
            id="btn-main-mic"
          >
            {isListening ? (
              <MicOff className="w-10 h-10 animate-pulse" />
            ) : (
              <Mic className="w-10 h-10" />
            )}
            <span className="text-[10px] uppercase font-extrabold tracking-wider mt-1">
              {isListening ? "Listening..." : "Tap to Speak"}
            </span>
          </button>
        </div>

        {/* Live soundwave animation when listening */}
        {isListening && (
          <div className="flex items-center justify-center gap-1.5 my-3 h-8">
            <div className="w-1 bg-indigo-400 rounded-full animate-wave-1" />
            <div className="w-1 bg-indigo-300 rounded-full animate-wave-2" />
            <div className="w-1 bg-indigo-500 rounded-full animate-wave-3" />
            <div className="w-1 bg-indigo-400 rounded-full animate-wave-4" />
            <div className="w-1 bg-indigo-300 rounded-full animate-wave-5" />
          </div>
        )}

        {/* Input Textbox with Auto-Detect Live Sampler */}
        <div className="mt-4 space-y-2">
          {sourceLang === "Auto Detect" && (
            <div className="flex items-center justify-between px-1">
              <span className="text-[11px] font-bold text-indigo-300 flex items-center gap-1.5 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full">
                <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
                <span>
                  Auto-Detect Active
                  {detectedLangName ? `: ${detectedLangName}` : " (Sampling Audio/Text...)"}
                </span>
              </span>
            </div>
          )}

          <div className="flex items-center gap-2 bg-slate-950/90 border border-slate-800 rounded-2xl p-2 focus-within:border-indigo-500/80 transition shadow-inner">
            <input
              type="text"
              value={inputText}
              onChange={(e) => {
                const val = e.target.value;
                setInputText(val);
                if (sourceLang === "Auto Detect" && val.trim().length >= 2) {
                  const sampled = sampleAndDetectLanguage(val);
                  setDetectedLangName(sampled.language);
                }
              }}
              onKeyDown={(e) => e.key === "Enter" && handleTranslateText(inputText)}
              placeholder={`Or type text in ${sourceLang === "Auto Detect" ? (detectedLangName || "Auto Detected Language") : sourceLang}...`}
              className="bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none w-full px-3 py-1.5"
              id="input-home-text"
            />
            <button
              onClick={() => handleTranslateText(inputText)}
              disabled={!inputText.trim() || isTranslating}
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold transition shadow-lg flex items-center justify-center shrink-0"
              id="btn-home-send"
            >
              {isTranslating ? (
                <Sparkles className="w-4 h-4 animate-spin text-white" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Dedicated Lecture, Seminar & Teaching Record Card */}
      {onOpenLectureModal && (
        <div className="bg-gradient-to-r from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-500/30 rounded-3xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 text-left">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-amber-500 flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/25">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-extrabold text-white tracking-tight">
                  Lecture & Seminar Studio
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Continuous Mode
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Record long teaching speeches, live translate & export formatted DOC files with Date, Timestamps & IP
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenLectureModal}
            className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-xs sm:text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition transform hover:scale-105 shrink-0 border border-indigo-400/30"
            id="btn-home-record-lecture"
          >
            <Mic className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>Record & Translate Speech</span>
          </button>
        </div>
      )}

      {/* Translations Feed / History */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            Live Translations
          </h2>
          {messages.length > 0 && (
            <button
              onClick={onClearHistory}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
              id="btn-clear-history"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear All
            </button>
          )}
        </div>

        {messages.length === 0 ? (
          <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-8 text-center text-slate-500 space-y-2">
            <Mic className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-sm font-medium">No spoken translations yet.</p>
            <p className="text-xs text-slate-600">
              Tap the microphone or type above to start translating in real-time.
            </p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {messages.map((msg) => {
              const isPlaying = isPlayingId === msg.id;
              const isCopied = copiedId === msg.id;
              const targetLangSpeech =
                SUPPORTED_LANGUAGES.find((l) => l.name === msg.targetLang)?.speechTag || "en-US";

              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 12, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-lg hover:border-slate-700 transition animate-fade-in"
                >
                  {/* Source Language Header */}
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      {msg.sourceLang}
                    </span>
                    <div className="flex items-center gap-2">
                      {msg.latencyMs !== undefined && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full" title="Real-time translation output">
                          <Zap className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>Real-time</span>
                        </span>
                      )}
                      <span className="text-[10px] text-slate-500">
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  </div>

                  {/* Source Text */}
                  <p className="text-sm text-slate-200 font-medium leading-relaxed">
                    {msg.sourceText}
                  </p>

                  {/* Translated Output Card */}
                  <div className="bg-indigo-950/40 border border-indigo-500/20 rounded-xl p-3 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider">
                        {msg.targetLang} Translation
                      </span>
                      <button
                        onClick={() => handlePlaySpeech(msg.id, msg.translatedText, targetLangSpeech)}
                        className="p-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 transition flex items-center gap-1 text-xs font-medium"
                      >
                        {isPlaying ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-rose-400" /> Stop
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5 text-indigo-400" /> Listen
                          </>
                        )}
                      </button>
                    </div>

                    {/* Translated Text */}
                    <p className="text-base font-bold text-white tracking-wide">
                      {msg.translatedText}
                    </p>

                    {/* Phonetic Romanization if available */}
                    {msg.romanization && (
                      <p className="text-xs text-indigo-300/80 italic font-mono">
                        Pronunciation: {msg.romanization}
                      </p>
                    )}
                  </div>

                  {/* Card Actions Footer */}
                  <div className="flex items-center justify-end gap-2 pt-1 text-slate-400">
                    {/* Copy Button */}
                    <button
                      onClick={() => handleCopy(msg.id, msg.translatedText)}
                      className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition flex items-center gap-1 text-xs"
                      title="Copy Translation"
                    >
                      {isCopied ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{isCopied ? "Copied" : "Copy"}</span>
                    </button>

                    {/* Favorite Toggle */}
                    <button
                      onClick={() => onToggleFavorite(msg)}
                      className={`p-1.5 rounded-lg hover:bg-slate-800 transition flex items-center gap-1 text-xs ${
                        msg.isFavorite ? "text-amber-400 font-bold" : "text-slate-400 hover:text-white"
                      }`}
                      title="Favorite"
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${msg.isFavorite ? "fill-amber-400 text-amber-400" : ""}`}
                      />
                      <span>{msg.isFavorite ? "Saved" : "Save"}</span>
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
};
