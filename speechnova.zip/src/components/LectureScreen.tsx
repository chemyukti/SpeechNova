import React, { useState, useEffect, useRef } from "react";
import {
  GraduationCap,
  Mic,
  MicOff,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Download,
  Copy,
  Check,
  Globe,
  Sliders,
  Volume2,
  BookOpen,
  FileText,
  Clock,
  Trash2,
  Zap,
  Tag,
  ChevronRight,
  ListOrdered,
  Scissors,
  Activity,
  VolumeX
} from "lucide-react";
import { SOURCE_LANGUAGES, SUPPORTED_LANGUAGES, AUTO_DETECT_LANGUAGE } from "../data/languages";
import { translateOfflineAsync } from "../utils/offlineTranslator";
import { speakText, stopSpeech } from "../utils/speech";
import { filterFillerWords } from "../utils/textCleaner";

export interface LectureChunk {
  id: string;
  timestamp: string;
  relativeOffset: string;
  originalText: string;
  translatedText: string;
  isPauseSegment?: boolean;
  pauseDurationSec?: number;
}

export interface LectureSession {
  id: string;
  title: string;
  date: string;
  speechType: string;
  sourceLang: string;
  targetLang: string;
  chunks: LectureChunk[];
  smartPausesCount: number;
  durationSeconds: number;
}

export type SpeechType =
  | "Classroom Teaching"
  | "University Lecture"
  | "Seminar & Keynote"
  | "Conference & Business"
  | "Workshop & Training";

const SPEECH_TYPES: { type: SpeechType; icon: React.FC<{ className?: string }>; label: string }[] = [
  { type: "Classroom Teaching", icon: BookOpen, label: "Classroom" },
  { type: "University Lecture", icon: GraduationCap, label: "Lecture" },
  { type: "Seminar & Keynote", icon: Globe, label: "Seminar" },
  { type: "Conference & Business", icon: Sparkles, label: "Conference" },
  { type: "Workshop & Training", icon: Volume2, label: "Workshop" },
];

interface LectureScreenProps {
  sourceLang: string;
  setSourceLang: (lang: string) => void;
  targetLang: string;
  setTargetLang: (lang: string) => void;
}

export const LectureScreen: React.FC<LectureScreenProps> = ({
  sourceLang,
  setSourceLang,
  targetLang,
  setTargetLang,
}) => {
  const [speechType, setSpeechType] = useState<SpeechType>("University Lecture");
  const [sessionTitle, setSessionTitle] = useState("Live Lecture & Seminar Session");

  // Recording & Live State
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState("");
  const [interimTranslation, setInterimTranslation] = useState("");

  const [chunks, setChunks] = useState<LectureChunk[]>([]);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [smartPausesCount, setSmartPausesCount] = useState(0);

  // Smart Pause Detection Settings
  const [enableSmartPause, setEnableSmartPause] = useState(true);
  const [pauseThresholdSec, setPauseThresholdSec] = useState<number>(2.5); // 1.5s, 2.5s, 4.0s
  const [lastSpeechTime, setLastSpeechTime] = useState<number>(Date.now());
  const [showPauseBadge, setShowPauseBadge] = useState<boolean>(false);
  const [micGain, setMicGain] = useState<number>(80);

  // Real-Time Audio Analysis & Volume Silence Trimming Module State
  const [audioVolume, setAudioVolume] = useState<number>(0); // 0 to 100
  const [silenceVolumeThreshold, setSilenceVolumeThreshold] = useState<number>(12); // Volume threshold %
  const [totalSilenceTrimmedSec, setTotalSilenceTrimmedSec] = useState<number>(0);
  const [isTrimmingSilence, setIsTrimmingSilence] = useState<boolean>(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const silenceStartRef = useRef<number | null>(null);
  const silenceThresholdRef = useRef<number>(12);
  const pauseThresholdSecRef = useRef<number>(2.5);

  useEffect(() => {
    silenceThresholdRef.current = silenceVolumeThreshold;
  }, [silenceVolumeThreshold]);

  useEffect(() => {
    pauseThresholdSecRef.current = pauseThresholdSec;
  }, [pauseThresholdSec]);

  // Real-time Web Audio API Volume Analyzer & Silence Detector
  const startAudioAnalyser = async () => {
    try {
      if (audioCtxRef.current) return;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioCtxRef.current = ctx;

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const updateVolume = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        const volumeLevel = Math.min(100, Math.round((avg / 128) * 100));
        setAudioVolume(volumeLevel);

        const now = Date.now();
        const curThreshold = silenceThresholdRef.current;
        const targetPauseSec = pauseThresholdSecRef.current;

        if (volumeLevel < curThreshold) {
          if (!silenceStartRef.current) {
            silenceStartRef.current = now;
          } else {
            const silentSec = (now - silenceStartRef.current) / 1000;
            if (silentSec >= targetPauseSec) {
              setIsTrimmingSilence(true);
              setTotalSilenceTrimmedSec((prev) => Math.round((prev + 0.1) * 10) / 10);
            }
          }
        } else {
          silenceStartRef.current = null;
          setIsTrimmingSilence(false);
        }

        animFrameRef.current = requestAnimationFrame(updateVolume);
      };

      updateVolume();
    } catch (e) {
      console.warn("Real-time audio analysis microphone initialization skipped:", e);
    }
  };

  const stopAudioAnalyser = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }
    if (audioCtxRef.current) {
      try { audioCtxRef.current.close(); } catch {}
      audioCtxRef.current = null;
    }
    analyserRef.current = null;
    setAudioVolume(0);
    setIsTrimmingSilence(false);
    silenceStartRef.current = null;
  };

  useEffect(() => {
    return () => {
      stopAudioAnalyser();
    };
  }, []);

  // View Mode: "live" | "summary" | "history"
  const [viewTab, setViewTab] = useState<"live" | "summary" | "history">("live");

  // Summarizer & Exports
  const [summaryPoints, setSummaryPoints] = useState<string[]>([]);
  const [keyTerms, setKeyTerms] = useState<{ word: string; meaning: string }[]>([]);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [copiedSession, setCopiedSession] = useState(false);
  const [exportedDoc, setExportedDoc] = useState(false);
  const [playingChunkId, setPlayingChunkId] = useState<string | null>(null);

  // Past Saved Sessions
  const [savedSessions, setSavedSessions] = useState<LectureSession[]>(() => {
    try {
      const stored = localStorage.getItem("speech_nova_lecture_sessions");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const recognizerRef = useRef<any>(null);
  const timerRef = useRef<any>(null);
  const pauseCheckIntervalRef = useRef<any>(null);
  const lastSpeechTimeRef = useRef<number>(Date.now());

  const sourceLangObj =
    SOURCE_LANGUAGES.find((l) => l.name === sourceLang) || AUTO_DETECT_LANGUAGE;

  const formatElapsed = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  // Timer ticker
  useEffect(() => {
    if (isRecording && !isPaused) {
      timerRef.current = setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecording, isPaused]);

  // Smart Pause Inspector Interval
  useEffect(() => {
    if (isRecording && !isPaused && enableSmartPause) {
      pauseCheckIntervalRef.current = setInterval(() => {
        const now = Date.now();
        const silenceGapSec = (now - lastSpeechTimeRef.current) / 1000;

        if (silenceGapSec >= pauseThresholdSec && interimTranscript.trim().length > 0) {
          // Trigger Smart Pause Auto-Segmentation
          triggerSmartPauseSegment(silenceGapSec);
        }
      }, 1000);
    } else {
      if (pauseCheckIntervalRef.current) clearInterval(pauseCheckIntervalRef.current);
    }
    return () => {
      if (pauseCheckIntervalRef.current) clearInterval(pauseCheckIntervalRef.current);
    };
  }, [isRecording, isPaused, enableSmartPause, pauseThresholdSec, interimTranscript]);

  const triggerSmartPauseSegment = async (gapSec: number) => {
    if (!interimTranscript.trim()) return;

    const currentText = interimTranscript.trim();
    setInterimTranscript("");
    setInterimTranslation("");

    const now = new Date();
    const timeString = now.toLocaleTimeString("en-US");
    const relOffset = `+${formatElapsed(elapsedSeconds)}`;

    const translatedRes = await translateOfflineAsync(currentText, sourceLang, targetLang);

    const newChunk: LectureChunk = {
      id: `chunk-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: timeString,
      relativeOffset: relOffset,
      originalText: currentText,
      translatedText: translatedRes.translatedText,
      isPauseSegment: true,
      pauseDurationSec: Math.round(gapSec * 10) / 10,
    };

    setChunks((prev) => [...prev, newChunk]);
    setSmartPausesCount((prev) => prev + 1);
    lastSpeechTimeRef.current = Date.now();
    setLastSpeechTime(Date.now());

    setShowPauseBadge(true);
    setTimeout(() => setShowPauseBadge(false), 3000);
  };

  // Start continuous speech recognition
  const startRecording = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. Please use Google Chrome or Microsoft Edge.");
      return;
    }

    try {
      if (recognizerRef.current) {
        try { recognizerRef.current.stop(); } catch {}
      }

      const recognizer = new SpeechRecognition();
      recognizer.continuous = true;
      recognizer.interimResults = true;

      const speechTag = sourceLang === "Auto Detect"
        ? (typeof navigator !== "undefined" && navigator.language ? navigator.language : "en-US")
        : sourceLangObj.speechTag;

      recognizer.lang = speechTag;

      recognizer.onresult = async (event: any) => {
        lastSpeechTimeRef.current = Date.now();
        setLastSpeechTime(Date.now());

        let interimStr = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const res = event.results[i];
          const rawText = res[0].transcript;
          const cleanedText = filterFillerWords(rawText, sourceLangObj.speechTag) || rawText;

          if (res.isFinal) {
            const finalClean = cleanedText.trim();
            if (finalClean) {
              const now = new Date();
              const timeString = now.toLocaleTimeString("en-US");
              const relOffset = `+${formatElapsed(elapsedSeconds)}`;

              const translatedRes = await translateOfflineAsync(
                finalClean,
                sourceLang,
                targetLang
              );

              const newChunk: LectureChunk = {
                id: `chunk-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                timestamp: timeString,
                relativeOffset: relOffset,
                originalText: finalClean,
                translatedText: translatedRes.translatedText,
              };

              setChunks((prev) => [...prev, newChunk]);
              setInterimTranscript("");
              setInterimTranslation("");
            }
          } else {
            interimStr += rawText;
          }
        }

        const cleanedInterim = filterFillerWords(interimStr, sourceLangObj.speechTag);
        if (cleanedInterim.trim()) {
          setInterimTranscript(cleanedInterim);
          translateOfflineAsync(cleanedInterim, sourceLang, targetLang)
            .then((r) => setInterimTranslation(r.translatedText))
            .catch(() => {});
        }
      };

      recognizer.onerror = (err: any) => {
        if (err?.error === "no-speech" && isRecording && !isPaused) {
          try { recognizer.start(); } catch {}
        }
      };

      recognizer.onend = () => {
        if (isRecording && !isPaused) {
          try { recognizer.start(); } catch {}
        }
      };

      recognizer.start();
      recognizerRef.current = recognizer;
      setIsRecording(true);
      setIsPaused(false);
      lastSpeechTimeRef.current = Date.now();
      setLastSpeechTime(Date.now());
      startAudioAnalyser();
    } catch (e) {
      console.error("Failed to start lecture speech recognition:", e);
    }
  };

  const pauseRecording = () => {
    setIsPaused(true);
    stopAudioAnalyser();
    if (recognizerRef.current) {
      try { recognizerRef.current.stop(); } catch {}
    }
  };

  const resumeRecording = () => {
    setIsPaused(false);
    startRecording();
  };

  const stopRecording = () => {
    setIsRecording(false);
    setIsPaused(false);
    stopAudioAnalyser();
    if (recognizerRef.current) {
      try { recognizerRef.current.stop(); } catch {}
      recognizerRef.current = null;
    }
  };

  const handleClearSession = () => {
    if (confirm("Clear current live lecture session?")) {
      stopRecording();
      stopAudioAnalyser();
      setChunks([]);
      setElapsedSeconds(0);
      setSmartPausesCount(0);
      setTotalSilenceTrimmedSec(0);
      setInterimTranscript("");
      setInterimTranslation("");
      setSummaryPoints([]);
      setKeyTerms([]);
    }
  };

  // Generate Smart Lesson Summary
  const handleGenerateSummary = () => {
    if (chunks.length === 0) return;
    setIsSummarizing(true);

    setTimeout(() => {
      const fullOriginal = chunks.map((c) => c.originalText).join(" ");
      const words = fullOriginal.split(/\s+/);

      // Extract bullet points
      const points: string[] = [];
      const chunkGroups: string[] = [];

      for (let i = 0; i < chunks.length; i += 2) {
        const group = chunks.slice(i, i + 2).map((c) => c.translatedText || c.originalText).join(". ");
        if (group.trim()) {
          chunkGroups.push(group.trim());
        }
      }

      if (chunkGroups.length > 0) {
        chunkGroups.slice(0, 5).forEach((group, idx) => {
          points.push(`Key Takeaway ${idx + 1}: ${group.substring(0, 140)}${group.length > 140 ? "..." : ""}`);
        });
      } else {
        points.push("Summary point: " + fullOriginal.substring(0, 150));
      }

      // Extract notable key terms (words > 6 letters)
      const uniqueBigWords = Array.from(
        new Set(
          words
            .map((w) => w.replace(/[^a-zA-Z]/g, "").toLowerCase())
            .filter((w) => w.length > 5)
        )
      ).slice(0, 6);

      const terms = uniqueBigWords.map((w) => ({
        word: w.charAt(0).toUpperCase() + w.slice(1),
        meaning: `Key terminology discussed during the ${speechType} session.`,
      }));

      setSummaryPoints(points);
      setKeyTerms(terms);
      setIsSummarizing(false);
      setViewTab("summary");
    }, 800);
  };

  // Save Session to Memory
  const handleSaveSession = () => {
    if (chunks.length === 0) return;

    const newSession: LectureSession = {
      id: `session-${Date.now()}`,
      title: sessionTitle || `${speechType} Session`,
      date: new Date().toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
      speechType,
      sourceLang,
      targetLang,
      chunks,
      smartPausesCount,
      durationSeconds: elapsedSeconds,
    };

    const updated = [newSession, ...savedSessions];
    setSavedSessions(updated);
    try {
      localStorage.setItem("speech_nova_lecture_sessions", JSON.stringify(updated));
    } catch {}

    alert("Lecture session saved to offline lesson history!");
  };

  const handleDeleteSavedSession = (id: string) => {
    const updated = savedSessions.filter((s) => s.id !== id);
    setSavedSessions(updated);
    try {
      localStorage.setItem("speech_nova_lecture_sessions", JSON.stringify(updated));
    } catch {}
  };

  // Export formatted lesson document
  const handleExportLesson = () => {
    if (chunks.length === 0) return;

    let docContent = `# ${sessionTitle}\n`;
    docContent += `Type: ${speechType} | Date: ${new Date().toLocaleDateString()}\n`;
    docContent += `Languages: ${sourceLang} ➔ ${targetLang}\n`;
    docContent += `Smart Pauses Auto-Segmented: ${smartPausesCount}\n\n`;
    docContent += `--- TRANSCRIPT & TRANSLATION ---\n\n`;

    chunks.forEach((chunk, index) => {
      docContent += `[${chunk.relativeOffset}] Paragraph ${index + 1}:\n`;
      docContent += `Original: ${chunk.originalText}\n`;
      docContent += `Translation: ${chunk.translatedText}\n`;
      if (chunk.isPauseSegment) {
        docContent += `(⏸️ Speaker Pause: ${chunk.pauseDurationSec || 2.5}s)\n`;
      }
      docContent += `\n`;
    });

    if (summaryPoints.length > 0) {
      docContent += `\n--- LESSON SUMMARY ---\n\n`;
      summaryPoints.forEach((p) => {
        docContent += `- ${p}\n`;
      });
    }

    const blob = new Blob([docContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${sessionTitle.replace(/[^a-zA-Z0-0]/g, "_")}_Notes.txt`;
    a.click();
    URL.revokeObjectURL(url);

    setExportedDoc(true);
    setTimeout(() => setExportedDoc(false), 2500);
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSession(true);
    setTimeout(() => setCopiedSession(false), 2000);
  };

  const handleSpeakChunk = (text: string, id: string) => {
    if (playingChunkId === id) {
      stopSpeech();
      setPlayingChunkId(null);
    } else {
      setPlayingChunkId(id);
      speakText(text, targetLang, () => setPlayingChunkId(null));
    }
  };

  return (
    <div className="p-3 sm:p-5 space-y-4 max-w-4xl mx-auto pb-24">
      {/* Top Banner & Control Deck */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-3xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-500/20 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-400/40 flex items-center justify-center text-amber-300 shadow-md">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={sessionTitle}
                  onChange={(e) => setSessionTitle(e.target.value)}
                  className="text-base sm:text-lg font-extrabold text-white bg-transparent border-b border-dashed border-indigo-400/50 focus:border-indigo-400 outline-none max-w-[220px] sm:max-w-[320px]"
                />
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Lecture Studio
                </span>
              </div>
              <p className="text-xs text-indigo-200/80 mt-0.5">
                Real-time lecture transcription, filler removal & smart pause auto-segmentation
              </p>
            </div>
          </div>

          {/* Recording Timer & Actions */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <div className="bg-slate-950/80 border border-slate-800 px-3.5 py-1.5 rounded-2xl flex items-center gap-2">
              <Clock className={`w-4 h-4 ${isRecording && !isPaused ? "text-amber-400 animate-pulse" : "text-slate-400"}`} />
              <span className="text-sm font-mono font-bold text-white">
                {formatElapsed(elapsedSeconds)}
              </span>
            </div>

            {isRecording ? (
              isPaused ? (
                <button
                  onClick={resumeRecording}
                  className="px-3.5 py-1.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-md"
                  id="btn-lecture-resume"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Resume</span>
                </button>
              ) : (
                <button
                  onClick={pauseRecording}
                  className="px-3.5 py-1.5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-md"
                  id="btn-lecture-pause"
                >
                  <Pause className="w-4 h-4 fill-current" />
                  <span>Pause</span>
                </button>
              )
            ) : null}

            {isRecording && (
              <button
                onClick={stopRecording}
                className="px-3.5 py-1.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-md"
                id="btn-lecture-stop"
              >
                <MicOff className="w-4 h-4" />
                <span>End Session</span>
              </button>
            )}
          </div>
        </div>

        {/* Speech Mode Selector & Language Pickers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-4">
          {/* Category/Type Picker */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Speech Environment
            </label>
            <select
              value={speechType}
              onChange={(e) => setSpeechType(e.target.value as SpeechType)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-indigo-300 focus:outline-none focus:border-indigo-500"
              id="select-speech-environment"
            >
              {SPEECH_TYPES.map((st) => (
                <option key={st.type} value={st.type}>
                  {st.label}
                </option>
              ))}
            </select>
          </div>

          {/* Source Language */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Speaker Language
            </label>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 focus:outline-none focus:border-indigo-500"
              id="select-lecture-source-lang"
            >
              <option value="Auto Detect">✨ Auto Detect Language</option>
              {SOURCE_LANGUAGES.map((l) => (
                <option key={l.name} value={l.name}>
                  {l.flag} {l.name}
                </option>
              ))}
            </select>
          </div>

          {/* Target Language */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Target Translation
            </label>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-purple-300 focus:outline-none focus:border-purple-500"
              id="select-lecture-target-lang"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.name} value={l.name}>
                  {l.flag} {l.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Big Recording Launch Trigger */}
        {!isRecording && (
          <div className="mt-4 pt-3 border-t border-indigo-500/20 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-indigo-200/90">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Real-time filler removal (filters 'um', 'uh', 'like') & Smart Silence Detection enabled</span>
            </div>

            <button
              onClick={startRecording}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-sm transition shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2"
              id="btn-start-lecture-recording"
            >
              <Mic className="w-5 h-5 text-amber-300 animate-pulse" />
              <span>Start Recording Lecture</span>
            </button>
          </div>
        )}
      </div>

      {/* Smart Pause Detection & Real-Time Audio Analysis Module Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-3.5 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
          {/* Smart Pause & Auto-Trimming Status Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setEnableSmartPause(!enableSmartPause)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                enableSmartPause
                  ? "bg-indigo-600/30 border-indigo-400/50 text-indigo-200"
                  : "bg-slate-950 border-slate-800 text-slate-400"
              }`}
              id="btn-toggle-smart-pause"
            >
              <Pause className="w-3.5 h-3.5 text-indigo-400" />
              <span>Smart Pause Detection: {enableSmartPause ? "ON" : "OFF"}</span>
            </button>

            {/* Silence Trimmed Stats Badge */}
            <span className="text-[11px] font-bold px-2.5 py-1 rounded-xl bg-purple-950/80 border border-purple-500/30 text-purple-200 flex items-center gap-1.5 shadow-sm">
              <Scissors className="w-3.5 h-3.5 text-amber-300" />
              <span>Trimmed Silence: {totalSilenceTrimmedSec.toFixed(1)}s</span>
            </span>

            {/* Auto-Trimming Live Banner */}
            {isTrimmingSilence && (
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                <span>Silence Interval Auto-Trimming...</span>
              </span>
            )}

            {/* Smart Pause Counter Badge */}
            <span className="text-[11px] font-bold px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 flex items-center gap-1">
              <Tag className="w-3 h-3 text-indigo-400" />
              <span>{smartPausesCount} Pauses Auto-Grouped</span>
            </span>

            {/* Smart Pause Live Alert Banner */}
            {showPauseBadge && (
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-bounce flex items-center gap-1">
                ⏸️ Pause Detected — Paragraph Auto-Segmented!
              </span>
            )}
          </div>

          {/* Pause Sensitivity Duration Selector */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-400 font-medium">Silence Interval:</span>
            {[1.5, 2.5, 4.0].map((val) => (
              <button
                key={val}
                onClick={() => setPauseThresholdSec(val)}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition border ${
                  pauseThresholdSec === val
                    ? "bg-indigo-600 text-white border-indigo-400"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                {val === 1.5 ? "1.5s Short" : val === 2.5 ? "2.5s Standard" : "4.0s Long"}
              </button>
            ))}
          </div>
        </div>

        {/* Real-time Volume Analyzer VU Meter & Silence Floor Threshold */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-0.5">
          {/* Live Mic Volume Level Meter */}
          <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <div className="flex items-center gap-1.5">
                <Activity className={`w-3.5 h-3.5 ${isRecording ? "text-emerald-400 animate-pulse" : "text-slate-500"}`} />
                <span>Real-Time Mic Audio Volume:</span>
                <span className={`font-mono font-bold ${audioVolume < silenceVolumeThreshold ? "text-amber-400" : "text-emerald-400"}`}>
                  {audioVolume}%
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-400">
                {audioVolume < silenceVolumeThreshold ? "Below Threshold (Silence)" : "Active Speech"}
              </span>
            </div>

            {/* VU Meter Visualizer Bar */}
            <div className="relative w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              {/* Volume fill */}
              <div
                className={`h-full transition-all duration-75 ${
                  audioVolume < silenceVolumeThreshold
                    ? "bg-amber-500/70"
                    : "bg-gradient-to-r from-emerald-500 via-indigo-500 to-purple-500"
                }`}
                style={{ width: `${audioVolume}%` }}
              />
              {/* Silence Threshold Marker */}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-10 shadow-sm"
                style={{ left: `${silenceVolumeThreshold}%` }}
                title={`Silence Floor Threshold (${silenceVolumeThreshold}%)`}
              />
            </div>
          </div>

          {/* Silence Volume Floor Threshold Control */}
          <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs gap-3">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold shrink-0">
              <VolumeX className="w-3.5 h-3.5 text-amber-400" />
              <span>Silence Floor Threshold:</span>
              <span className="text-amber-400 font-bold">{silenceVolumeThreshold}%</span>
            </div>

            <div className="flex items-center gap-2 flex-1 max-w-xs">
              <input
                type="range"
                min="5"
                max="35"
                step="1"
                value={silenceVolumeThreshold}
                onChange={(e) => setSilenceVolumeThreshold(parseInt(e.target.value, 10))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-900 rounded-lg appearance-none"
                id="slider-silence-volume-threshold"
              />
            </div>

            <div className="flex items-center gap-1">
              {[8, 12, 20].map((val) => (
                <button
                  key={val}
                  onClick={() => setSilenceVolumeThreshold(val)}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                    silenceVolumeThreshold === val
                      ? "bg-amber-500 text-slate-950 border-amber-400"
                      : "bg-slate-900 text-slate-400 border-slate-800"
                  }`}
                >
                  {val}%
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main View Navigation Tabs (Live Stream, Summary & Takeaways, Saved Lessons) */}
      <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setViewTab("live")}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
              viewTab === "live"
                ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
            }`}
            id="tab-lecture-live"
          >
            <Mic className="w-4 h-4 text-amber-300" />
            <span>Live Transcript & Translation</span>
            {chunks.length > 0 && (
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-950 text-indigo-300 font-bold">
                {chunks.length}
              </span>
            )}
          </button>

          <button
            onClick={handleGenerateSummary}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
              viewTab === "summary"
                ? "bg-purple-600 text-white border-purple-400 shadow-md"
                : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
            }`}
            id="tab-lecture-summary"
          >
            <Sparkles className={`w-4 h-4 ${isSummarizing ? "animate-spin text-amber-300" : "text-purple-400"}`} />
            <span>Lesson Highlights & Summary</span>
          </button>

          <button
            onClick={() => setViewTab("history")}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
              viewTab === "history"
                ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
            }`}
            id="tab-lecture-history"
          >
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span>Saved Lessons ({savedSessions.length})</span>
          </button>
        </div>

        {/* Global Lesson Export & Save Controls */}
        <div className="flex items-center gap-1.5">
          {chunks.length > 0 && (
            <>
              <button
                onClick={handleSaveSession}
                title="Save session to memory"
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-bold transition flex items-center gap-1"
                id="btn-lecture-save-memory"
              >
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Save</span>
              </button>

              <button
                onClick={handleExportLesson}
                title="Export Lesson Notes Document"
                className="px-2.5 py-1.5 rounded-xl bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-500/40 text-xs font-bold transition flex items-center gap-1"
                id="btn-lecture-export-doc"
              >
                {exportedDoc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Download className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{exportedDoc ? "Exported!" : "Export Notes"}</span>
              </button>

              <button
                onClick={handleClearSession}
                title="Clear Session"
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-rose-400 border border-slate-800 text-xs transition"
                id="btn-lecture-clear"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* VIEW 1: LIVE TRANSCRIPT & TRANSLATION STREAM */}
      {viewTab === "live" && (
        <div className="space-y-3">
          {/* Active Interim Live Preview */}
          {(interimTranscript || interimTranslation) && (
            <div className="bg-indigo-950/60 border border-indigo-500/50 rounded-2xl p-4 space-y-2 animate-pulse shadow-lg">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-300">
                <span className="flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 text-amber-300 animate-bounce" />
                  <span>Live Speaking Preview...</span>
                </span>
                <span className="text-[10px] text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
                  Filler Words Filtered
                </span>
              </div>
              <p className="text-sm font-medium text-white italic">"{interimTranscript}"</p>
              {interimTranslation && (
                <p className="text-sm font-semibold text-purple-300 border-t border-indigo-500/30 pt-2">
                  ➔ {interimTranslation}
                </p>
              )}
            </div>
          )}

          {/* List of Formatted Lecture Chunks */}
          {chunks.length === 0 && !interimTranscript ? (
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-3xl p-8 sm:p-12 text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mx-auto">
                <GraduationCap className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-white">No Lecture Recording Active</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                Click "Start Recording Lecture" above to capture classroom lessons, university lectures, or keynotes. SpeechNova automatically removes hesitations ("um", "uh", "like") and uses smart pause detection to auto-group paragraphs.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {chunks.map((chunk, index) => (
                <div
                  key={chunk.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-md hover:border-slate-700 transition"
                >
                  {/* Chunk Metadata Bar */}
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-indigo-400 bg-indigo-950 px-2.5 py-0.5 rounded-lg border border-indigo-500/30">
                        #{index + 1}
                      </span>
                      <span className="font-mono text-slate-400 text-[11px]">{chunk.timestamp}</span>
                      <span className="text-[10px] text-slate-500 font-mono">({chunk.relativeOffset})</span>
                    </div>

                    {chunk.isPauseSegment && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                        ⏸️ Smart Pause ({chunk.pauseDurationSec || 2.5}s)
                      </span>
                    )}
                  </div>

                  {/* Speech & Translation Content */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    {/* Original Clean Speech */}
                    <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 space-y-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        Clean Lecture Transcript ({sourceLang}):
                      </span>
                      <p className="text-xs text-slate-200 leading-relaxed font-medium">
                        {chunk.originalText}
                      </p>
                    </div>

                    {/* Live Translation Output */}
                    <div className="bg-purple-950/30 p-3 rounded-xl border border-purple-500/20 space-y-1 relative group">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider block">
                          Translated Output ({targetLang}):
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleSpeakChunk(chunk.translatedText, chunk.id)}
                            title="Listen to translation"
                            className="p-1 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200"
                          >
                            <Volume2 className={`w-3.5 h-3.5 ${playingChunkId === chunk.id ? "animate-bounce text-amber-300" : ""}`} />
                          </button>
                          <button
                            onClick={() => handleCopyText(chunk.translatedText)}
                            title="Copy translation"
                            className="p-1 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-purple-100 font-semibold leading-relaxed">
                        {chunk.translatedText}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: LESSON HIGHLIGHTS & SUMMARY */}
      {viewTab === "summary" && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-300" />
              <div>
                <h3 className="text-base font-bold text-white">Automated Lesson Summary & Key Concepts</h3>
                <p className="text-xs text-slate-400">Intelligent takeaway breakdown generated from live lecture transcript</p>
              </div>
            </div>

            <button
              onClick={handleGenerateSummary}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Regenerate Summary</span>
            </button>
          </div>

          {summaryPoints.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              No summary generated yet. Click "Lesson Highlights & Summary" above to auto-summarize your current session.
            </div>
          ) : (
            <div className="space-y-5">
              {/* Bulleted Takeaways */}
              <div className="space-y-3">
                <h4 className="text-xs font-extrabold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                  <ListOrdered className="w-4 h-4 text-indigo-400" />
                  <span>Core Takeaways & Topics</span>
                </h4>
                <div className="space-y-2">
                  {summaryPoints.map((point, idx) => (
                    <div key={idx} className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl flex items-start gap-3">
                      <span className="w-6 h-6 rounded-xl bg-indigo-600/30 text-indigo-300 text-xs font-bold flex items-center justify-center shrink-0 border border-indigo-500/30">
                        {idx + 1}
                      </span>
                      <p className="text-xs text-slate-200 font-medium leading-relaxed pt-0.5">{point}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Terminology */}
              {keyTerms.length > 0 && (
                <div className="space-y-3 pt-2 border-t border-slate-800">
                  <h4 className="text-xs font-extrabold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-purple-400" />
                    <span>Key Lesson Vocabulary Terms</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {keyTerms.map((term, i) => (
                      <div key={i} className="bg-purple-950/30 border border-purple-500/20 p-3 rounded-2xl space-y-1">
                        <span className="text-xs font-bold text-amber-300 block">{term.word}</span>
                        <p className="text-[11px] text-purple-200/80">{term.meaning}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* VIEW 3: SAVED LESSON HISTORY */}
      {viewTab === "history" && (
        <div className="space-y-3">
          {savedSessions.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center text-slate-400 text-xs space-y-2">
              <BookOpen className="w-8 h-8 text-slate-500 mx-auto" />
              <p className="font-bold text-white">No Saved Lessons Yet</p>
              <p>Record a lecture session and click "Save" to build your offline lesson library.</p>
            </div>
          ) : (
            savedSessions.map((session) => (
              <div
                key={session.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-md hover:border-slate-700 transition"
              >
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div>
                    <h4 className="text-sm font-bold text-white">{session.title}</h4>
                    <p className="text-[11px] text-slate-400">
                      {session.date} • {session.speechType} • {session.sourceLang} ➔ {session.targetLang}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setChunks(session.chunks);
                        setSessionTitle(session.title);
                        setSpeechType(session.speechType as SpeechType);
                        setSourceLang(session.sourceLang);
                        setTargetLang(session.targetLang);
                        setViewTab("live");
                      }}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition"
                    >
                      Load Session
                    </button>

                    <button
                      onClick={() => handleDeleteSavedSession(session.id)}
                      className="p-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-rose-400 border border-slate-800 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 italic">
                  "{session.chunks.slice(0, 2).map((c) => c.originalText).join(" ")}"
                </p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
