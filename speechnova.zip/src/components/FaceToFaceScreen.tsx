import React, { useState, useEffect, useRef } from "react";
import { SUPPORTED_LANGUAGES } from "../data/languages";
import { createSpeechRecognizer, speakText, stopSpeech } from "../utils/speech";
import { translateOffline } from "../utils/offlineTranslator";
import {
  Users,
  Mic,
  MicOff,
  Volume2,
  RotateCw,
  Trash2,
  Sparkles,
  Play,
  Pause,
  Repeat,
  Zap,
  ArrowDownUp,
  VolumeX,
  Radio
} from "lucide-react";

interface FaceToFaceScreenProps {
  sourceLang: string;
  targetLang: string;
}

interface ConversationTurn {
  id: string;
  speaker: "user" | "partner";
  text: string;
  translation: string;
  timestamp: number;
}

export const FaceToFaceScreen: React.FC<FaceToFaceScreenProps> = ({
  sourceLang,
  targetLang,
}) => {
  const [turns, setTurns] = useState<ConversationTurn[]>([]);
  const [isFlippedTopCard, setIsFlippedTopCard] = useState(false); // Flip 180° for sitting across table
  const [activeSpeaker, setActiveSpeaker] = useState<"user" | "partner" | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isContinuousMode, setIsContinuousMode] = useState(false);
  const [interimText, setInterimText] = useState("");

  const recognizerRef = useRef<any>(null);
  const isContinuousRef = useRef(isContinuousMode);
  const activeSpeakerRef = useRef(activeSpeaker);

  useEffect(() => {
    isContinuousRef.current = isContinuousMode;
  }, [isContinuousMode]);

  useEffect(() => {
    activeSpeakerRef.current = activeSpeaker;
  }, [activeSpeaker]);

  // Clean up speech recognition on unmount
  useEffect(() => {
    return () => {
      if (recognizerRef.current) {
        try {
          recognizerRef.current.stop();
        } catch (e) {}
      }
      stopSpeech();
    };
  }, []);

  const sourceLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.name === sourceLang) || SUPPORTED_LANGUAGES[0];
  const targetLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.name === targetLang) || SUPPORTED_LANGUAGES[1];

  const handleTranslateAndSpeak = async (
    speaker: "user" | "partner",
    text: string
  ) => {
    if (!text.trim()) {
      if (isContinuousRef.current) {
        // Re-arm for next turn if empty
        const nextSpeaker = speaker === "user" ? "partner" : "user";
        setTimeout(() => startListeningForSpeaker(nextSpeaker), 800);
      }
      return;
    }

    setIsTranslating(true);
    const fromLang = speaker === "user" ? sourceLang : targetLang;
    const toLang = speaker === "user" ? targetLang : sourceLang;
    const toSpeechTag = speaker === "user" ? targetLangObj.speechTag : sourceLangObj.speechTag;

    let translation = "";

    try {
      if (typeof navigator !== "undefined" && !navigator.onLine) {
        const offlineRes = translateOffline(text, fromLang, toLang);
        translation = offlineRes.translatedText;
      } else {
        const res = await fetch("/api/translate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text,
            sourceLang: fromLang,
            targetLang: toLang,
          }),
        });
        const data = await res.json();
        translation = data.translatedText || text;
      }
    } catch (err) {
      console.warn("Online translation failed, using offline fallback:", err);
      const offlineRes = translateOffline(text, fromLang, toLang);
      translation = offlineRes.translatedText;
    } finally {
      setIsTranslating(false);
    }

    const newTurn: ConversationTurn = {
      id: Date.now().toString(),
      speaker,
      text,
      translation,
      timestamp: Date.now(),
    };

    setTurns((prev) => [...prev, newTurn]);

    // Automatically speak translation aloud
    speakText(translation, toSpeechTag, () => {
      // Callback after TTS finishes speaking
      if (isContinuousRef.current) {
        const nextSpeaker = speaker === "user" ? "partner" : "user";
        setTimeout(() => {
          if (isContinuousRef.current) {
            startListeningForSpeaker(nextSpeaker);
          }
        }, 600);
      } else {
        setActiveSpeaker(null);
        setIsListening(false);
      }
    });
  };

  const startListeningForSpeaker = (speaker: "user" | "partner") => {
    if (recognizerRef.current) {
      try {
        recognizerRef.current.stop();
      } catch (e) {}
    }

    const speechTag = speaker === "user" ? sourceLangObj.speechTag : targetLangObj.speechTag;
    
    const recognizer = createSpeechRecognizer(speechTag, {
      onResult: (transcript, isFinal) => {
        setInterimText(transcript);
        if (isFinal) {
          setInterimText("");
          if (recognizerRef.current) {
            try {
              recognizerRef.current.stop();
            } catch (e) {}
          }
          setIsListening(false);
          handleTranslateAndSpeak(speaker, transcript);
        }
      },
      onError: (err) => {
        console.warn("Speech recognition error:", err);
        setIsListening(false);
        setInterimText("");
        if (isContinuousRef.current) {
          // Retry re-arm after error in continuous mode
          setTimeout(() => {
            if (isContinuousRef.current) startListeningForSpeaker(speaker);
          }, 1200);
        } else {
          setActiveSpeaker(null);
        }
      },
      onEnd: () => {
        setIsListening(false);
      },
    });

    if (recognizer) {
      recognizerRef.current = recognizer;
      try {
        recognizer.start();
        setIsListening(true);
        setActiveSpeaker(speaker);
      } catch (e) {
        console.error("Recognizer start error:", e);
        setIsListening(false);
      }
    } else {
      alert("Speech recognition is not supported in this browser.");
      setIsContinuousMode(false);
    }
  };

  const toggleContinuousConversation = () => {
    if (isContinuousMode) {
      setIsContinuousMode(false);
      if (recognizerRef.current) {
        try {
          recognizerRef.current.stop();
        } catch (e) {}
      }
      stopSpeech();
      setIsListening(false);
      setActiveSpeaker(null);
    } else {
      setIsContinuousMode(true);
      startListeningForSpeaker("user");
    }
  };

  const handleManualMicClick = (speaker: "user" | "partner") => {
    if (isListening && activeSpeaker === speaker) {
      // Stop listening
      if (recognizerRef.current) {
        try {
          recognizerRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
      setActiveSpeaker(null);
      if (isContinuousMode) setIsContinuousMode(false);
    } else {
      startListeningForSpeaker(speaker);
    }
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-3xl mx-auto space-y-4">
      {/* Top Controls & Mode Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2 shadow-lg">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-indigo-400" />
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Face-to-Face Conversation
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Flip 180° for Table Setup */}
          <button
            onClick={() => setIsFlippedTopCard(!isFlippedTopCard)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 border ${
              isFlippedTopCard
                ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                : "bg-slate-800 text-slate-300 border-slate-700 hover:text-white"
            }`}
            title="Flip partner view 180° for sitting across table"
            id="btn-flip-table"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Flip 180°</span>
          </button>

          {turns.length > 0 && (
            <button
              onClick={() => {
                setTurns([]);
                stopSpeech();
              }}
              className="p-1.5 rounded-xl bg-slate-800 text-rose-400 hover:text-rose-300 transition border border-slate-700"
              title="Clear Conversation History"
              id="btn-clear-f2f"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* CONTINUOUS HANDS-FREE BANNER & TOGGLE */}
      <div
        className={`rounded-2xl p-4 border transition-all duration-300 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg ${
          isContinuousMode
            ? "bg-gradient-to-r from-indigo-950 via-purple-950 to-slate-900 border-indigo-500/50 ring-2 ring-indigo-500/30"
            : "bg-slate-900 border-slate-800"
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`p-2.5 rounded-xl ${
              isContinuousMode
                ? "bg-indigo-600 text-white animate-pulse"
                : "bg-slate-800 text-slate-400"
            }`}
          >
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">
                Continuous Hands-Free Conversation
              </h3>
              {isContinuousMode && (
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse">
                  Live Active
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              {isContinuousMode
                ? "Hands-free mode active! Talk naturally — automatically listens & alternates turns."
                : "Enable hands-free mode for automated continuous listening without pressing buttons."}
            </p>
          </div>
        </div>

        <button
          onClick={toggleContinuousConversation}
          className={`w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 border shadow-md shrink-0 ${
            isContinuousMode
              ? "bg-rose-600 hover:bg-rose-500 text-white border-rose-400 animate-pulse"
              : "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white border-indigo-400/50"
          }`}
          id="btn-toggle-continuous"
        >
          {isContinuousMode ? (
            <>
              <Pause className="w-4 h-4 fill-current" />
              <span>Pause Hands-Free</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 text-amber-300 fill-current" />
              <span>Start Continuous Mode</span>
            </>
          )}
        </button>
      </div>

      {/* SPLIT SCREEN CONTAINER */}
      <div className="space-y-4">
        {/* TOP CARD: PARTNER / RECIPIENT */}
        <div
          className={`bg-slate-900 border rounded-3xl p-5 shadow-xl transition-all duration-300 relative ${
            isFlippedTopCard ? "rotate-180" : ""
          } ${
            activeSpeaker === "partner" && isListening
              ? "border-rose-500/80 ring-2 ring-rose-500/20 bg-slate-900/90"
              : "border-slate-800"
          }`}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">{targetLangObj.flag}</span>
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
                Partner ({targetLang})
              </span>
            </div>
            {activeSpeaker === "partner" && isListening && (
              <span className="text-[10px] font-bold text-rose-400 animate-pulse bg-rose-500/20 px-2.5 py-1 rounded-full flex items-center gap-1 border border-rose-500/30">
                <Mic className="w-3 h-3" />
                Listening Partner...
              </span>
            )}
          </div>

          {/* Latest Partner Message or Placeholder */}
          <div className="min-h-[100px] flex flex-col justify-center">
            {activeSpeaker === "partner" && interimText ? (
              <div className="space-y-1 bg-slate-950/80 p-3 rounded-2xl border border-rose-500/30">
                <span className="text-[10px] font-bold text-rose-400 uppercase">Live Speaking:</span>
                <p className="text-sm font-semibold text-rose-200 animate-pulse">{interimText}</p>
              </div>
            ) : turns.filter((t) => t.speaker === "partner").length === 0 ? (
              <p className="text-xs text-slate-500 italic text-center">
                Partner speaks in {targetLang}. Speech will translate automatically.
              </p>
            ) : (
              (() => {
                const last = [...turns].reverse().find((t) => t.speaker === "partner");
                if (!last) return null;
                return (
                  <div className="space-y-1.5">
                    <p className="text-sm font-bold text-white">{last.text}</p>
                    <div className="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/20 flex items-start justify-between gap-2">
                      <p className="text-xs font-semibold text-indigo-200">
                        <span className="text-indigo-400 font-bold">Translation ({sourceLang}):</span> {last.translation}
                      </p>
                      <button
                        onClick={() => speakText(last.translation, sourceLangObj.speechTag)}
                        className="p-1 rounded-lg bg-indigo-600/30 text-indigo-300 hover:text-white shrink-0"
                        title="Replay Audio"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })()
            )}
          </div>

          {/* Partner Mic Trigger Button */}
          <button
            onClick={() => handleManualMicClick("partner")}
            className={`w-full mt-3 py-3 rounded-2xl font-bold text-xs transition flex items-center justify-center gap-2 border ${
              activeSpeaker === "partner" && isListening
                ? "bg-rose-600 text-white border-rose-400 animate-pulse shadow-lg"
                : "bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border-indigo-500/30"
            }`}
            id="btn-partner-mic"
          >
            <Mic className="w-4 h-4" />
            <span>
              {activeSpeaker === "partner" && isListening
                ? "Listening Partner... Tap to Stop"
                : `Speak Partner (${targetLang})`}
            </span>
          </button>
        </div>

        {/* BOTTOM CARD: USER / SELF */}
        <div
          className={`bg-slate-900 border rounded-3xl p-5 shadow-xl relative transition-all duration-300 ${
            activeSpeaker === "user" && isListening
              ? "border-rose-500/80 ring-2 ring-rose-500/20 bg-slate-900/90"
              : "border-slate-800"
          }`}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">{sourceLangObj.flag}</span>
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
                You ({sourceLang})
              </span>
            </div>
            {activeSpeaker === "user" && isListening && (
              <span className="text-[10px] font-bold text-rose-400 animate-pulse bg-rose-500/20 px-2.5 py-1 rounded-full flex items-center gap-1 border border-rose-500/30">
                <Mic className="w-3 h-3" />
                Listening You...
              </span>
            )}
          </div>

          {/* Latest User Message or Placeholder */}
          <div className="min-h-[100px] flex flex-col justify-center">
            {activeSpeaker === "user" && interimText ? (
              <div className="space-y-1 bg-slate-950/80 p-3 rounded-2xl border border-rose-500/30">
                <span className="text-[10px] font-bold text-rose-400 uppercase">Live Speaking:</span>
                <p className="text-sm font-semibold text-rose-200 animate-pulse">{interimText}</p>
              </div>
            ) : turns.filter((t) => t.speaker === "user").length === 0 ? (
              <p className="text-xs text-slate-500 italic text-center">
                Speak in {sourceLang}. Speech will translate automatically.
              </p>
            ) : (
              (() => {
                const last = [...turns].reverse().find((t) => t.speaker === "user");
                if (!last) return null;
                return (
                  <div className="space-y-1.5">
                    <p className="text-sm font-bold text-white">{last.text}</p>
                    <div className="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/20 flex items-start justify-between gap-2">
                      <p className="text-xs font-semibold text-indigo-200">
                        <span className="text-indigo-400 font-bold">Translation ({targetLang}):</span> {last.translation}
                      </p>
                      <button
                        onClick={() => speakText(last.translation, targetLangObj.speechTag)}
                        className="p-1 rounded-lg bg-indigo-600/30 text-indigo-300 hover:text-white shrink-0"
                        title="Replay Audio"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })()
            )}
          </div>

          {/* User Mic Trigger Button */}
          <button
            onClick={() => handleManualMicClick("user")}
            className={`w-full mt-3 py-3 rounded-2xl font-bold text-xs transition flex items-center justify-center gap-2 border ${
              activeSpeaker === "user" && isListening
                ? "bg-rose-600 text-white border-rose-400 animate-pulse shadow-lg"
                : "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-400/50 shadow-lg"
            }`}
            id="btn-user-mic"
          >
            <Mic className="w-4 h-4" />
            <span>
              {activeSpeaker === "user" && isListening
                ? "Listening You... Tap to Stop"
                : `Speak You (${sourceLang})`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

