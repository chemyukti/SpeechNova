import React, { useState, useEffect } from "react";
import confetti from "canvas-confetti";
import { MASTER_VOCABULARY } from "../data/vocab";
import {
  getCurrentLearner,
  setCurrentLearner,
  getLeaderboard,
  addPoints,
} from "../utils/storage";
import { Learner } from "../types";
import {
  Award,
  Trophy,
  CheckCircle2,
  XCircle,
  User,
  Plus,
  RefreshCw,
  Sparkles,
  Flame
} from "lucide-react";

interface QuizScreenProps {
  targetLang: string;
}

export const QuizScreen: React.FC<QuizScreenProps> = ({ targetLang }) => {
  const [currentLearnerName, setCurrentLearnerName] = useState(() => getCurrentLearner());
  const [leaderboard, setLeaderboard] = useState<Learner[]>(() => getLeaderboard());
  const [showSwitchProfileModal, setShowSwitchProfileModal] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");

  // Quiz Game State
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [streak, setStreak] = useState(0);

  // Generate current question
  const vocabItem = MASTER_VOCABULARY[questionIndex % MASTER_VOCABULARY.length];
  const correctAnswer = vocabItem.translations[targetLang] || vocabItem.english;

  // Generate 3 distractors
  const distractors = MASTER_VOCABULARY.filter((v) => v.id !== vocabItem.id)
    .map((v) => v.translations[targetLang] || v.english)
    .sort(() => 0.5 - Math.random())
    .slice(0, 3);

  const options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());

  const handleSelectOption = (opt: string) => {
    if (isAnswered) return;
    setSelectedOption(opt);
    setIsAnswered(true);

    if (opt === correctAnswer) {
      // Confetti celebration!
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });

      const pts = 10 + streak * 2;
      addPoints(pts);
      setStreak((prev) => prev + 1);
      setLeaderboard(getLeaderboard());
    } else {
      setStreak(0);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    setQuestionIndex((prev) => prev + 1);
  };

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) return;
    setCurrentLearner(newProfileName.trim());
    setCurrentLearnerName(getCurrentLearner());
    setLeaderboard(getLeaderboard());
    setNewProfileName("");
    setShowSwitchProfileModal(false);
  };

  const currentLearnerPoints =
    leaderboard.find((l) => l.name.toLowerCase() === currentLearnerName.toLowerCase())
      ?.points || 0;

  return (
    <div className="pb-24 pt-4 px-4 max-w-3xl mx-auto space-y-5">
      {/* Quiz Banner & Active Profile Header */}
      <div className="bg-gradient-to-r from-amber-900 via-amber-950 to-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl font-extrabold text-white">Vocabulary Quiz Game</h1>
          </div>
          <p className="text-xs text-amber-200/80 mt-1">
            Testing <span className="text-amber-300 font-bold">{targetLang}</span> vocabulary
          </p>
        </div>

        {/* Player Profile Badge */}
        <button
          onClick={() => setShowSwitchProfileModal(true)}
          className="bg-slate-900/90 border border-amber-500/30 hover:border-amber-400 rounded-2xl px-3 py-2 text-right transition"
          id="btn-quiz-profile"
        >
          <div className="flex items-center gap-1.5 justify-end">
            <User className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-xs font-bold text-white">{currentLearnerName}</span>
          </div>
          <span className="text-xs font-extrabold text-amber-400 block">
            {currentLearnerPoints} PTS
          </span>
        </button>
      </div>

      {/* QUIZ CARD */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5 relative overflow-hidden">
        {/* Streak Counter Badge */}
        {streak > 1 && (
          <div className="inline-flex items-center gap-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-extrabold px-3 py-1 rounded-full animate-bounce">
            <Flame className="w-4 h-4 text-amber-400" /> {streak}x Streak Bonus!
          </div>
        )}

        <div className="space-y-1">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            Question #{questionIndex + 1}
          </span>
          <h2 className="text-xl font-bold text-white">
            What is the <span className="text-amber-300">{targetLang}</span> translation for:
          </h2>
          <p className="text-2xl font-black text-indigo-300 bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center tracking-wide">
            "{vocabItem.english}"
          </p>
        </div>

        {/* Multiple Choice Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {options.map((opt, idx) => {
            const isSelected = selectedOption === opt;
            const isCorrect = opt === correctAnswer;

            let btnStyle =
              "bg-slate-950 border-slate-800 hover:border-amber-500/50 text-slate-200";

            if (isAnswered) {
              if (isCorrect) {
                btnStyle =
                  "bg-emerald-950/80 border-emerald-500 text-emerald-200 shadow-lg shadow-emerald-500/20";
              } else if (isSelected) {
                btnStyle = "bg-rose-950/80 border-rose-500 text-rose-200";
              } else {
                btnStyle = "bg-slate-950/40 border-slate-900 text-slate-600 opacity-50";
              }
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(opt)}
                disabled={isAnswered}
                className={`p-4 rounded-2xl border font-bold text-sm text-left transition flex items-center justify-between ${btnStyle}`}
              >
                <span>{opt}</span>
                {isAnswered && isCorrect && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                )}
                {isAnswered && isSelected && !isCorrect && (
                  <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Next Question Button */}
        {isAnswered && (
          <div className="pt-2 text-center">
            <button
              onClick={handleNextQuestion}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm transition shadow-xl inline-flex items-center gap-2"
              id="btn-quiz-next"
            >
              <span>Next Question</span>
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* LEADERBOARD TABLE */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3 shadow-xl">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Trophy className="w-4 h-4 text-amber-400" />
          Learner Leaderboard
        </h3>

        <div className="space-y-2">
          {leaderboard.map((learner, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-2xl border flex items-center justify-between text-xs ${
                learner.name.toLowerCase() === currentLearnerName.toLowerCase()
                  ? "bg-amber-950/30 border-amber-500/40 text-amber-200 font-bold"
                  : "bg-slate-950 border-slate-800 text-slate-300"
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-lg bg-slate-800 text-amber-400 font-black flex items-center justify-center text-xs">
                  #{idx + 1}
                </span>
                <span>{learner.name}</span>
              </div>
              <span className="font-extrabold text-amber-400">{learner.points} PTS</span>
            </div>
          ))}
        </div>
      </div>

      {/* SWITCH / CREATE PROFILE MODAL */}
      {showSwitchProfileModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Learner Profile</h3>
            <form onSubmit={handleCreateProfile} className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  Enter Your Name / Profile Name
                </label>
                <input
                  type="text"
                  required
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  placeholder="e.g. Aarav"
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none w-full"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSwitchProfileModal(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-extrabold"
                >
                  Switch Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
