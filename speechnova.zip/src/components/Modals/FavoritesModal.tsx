import React from "react";
import { X, Star, Volume2, Copy, Trash2 } from "lucide-react";
import { TranslationMessage } from "../../types";
import { speakText } from "../../utils/speech";
import { SUPPORTED_LANGUAGES } from "../../data/languages";

interface FavoritesModalProps {
  isOpen: boolean;
  onClose: () => void;
  favorites: TranslationMessage[];
  onToggleFavorite: (msg: TranslationMessage) => void;
}

export const FavoritesModal: React.FC<FavoritesModalProps> = ({
  isOpen,
  onClose,
  favorites,
  onToggleFavorite,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <h2 className="text-base font-bold text-white">Saved Favorites ({favorites.length})</h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {favorites.length === 0 ? (
          <div className="p-8 text-center text-slate-500 space-y-2">
            <Star className="w-8 h-8 text-slate-700 mx-auto" />
            <p className="text-xs font-medium">No saved favorite translations yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {favorites.map((msg) => {
              const speechTag =
                SUPPORTED_LANGUAGES.find((l) => l.name === msg.targetLang)?.speechTag || "en-US";
              return (
                <div
                  key={msg.id}
                  className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 space-y-2"
                >
                  <p className="text-xs text-slate-400">{msg.sourceText}</p>
                  <p className="text-sm font-bold text-amber-300">{msg.translatedText}</p>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                    <span className="text-[10px] uppercase text-slate-500">
                      {msg.sourceLang} → {msg.targetLang}
                    </span>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => speakText(msg.translatedText, speechTag)}
                        className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onToggleFavorite(msg)}
                        className="p-1.5 rounded-lg bg-rose-600/20 text-rose-400"
                        title="Remove from favorites"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
