import React, { useState } from "react";
import { X, Edit3, Send, Sparkles, Volume2, Copy, Check } from "lucide-react";
import { speakText } from "../../utils/speech";
import { SUPPORTED_LANGUAGES } from "../../data/languages";

interface TypePasteModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetLang: string;
}

export const TypePasteModal: React.FC<TypePasteModalProps> = ({
  isOpen,
  onClose,
  targetLang,
}) => {
  const [text, setText] = useState("");
  const [translated, setTranslated] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const targetLangSpeechTag =
    SUPPORTED_LANGUAGES.find((l) => l.name === targetLang)?.speechTag || "en-US";

  const handleTranslate = async () => {
    if (!text.trim()) return;
    setIsTranslating(true);
    try {
      const res = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          sourceLang: "Auto Detect",
          targetLang,
        }),
      });
      const data = await res.json();
      setTranslated(data.translatedText || text);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleCopy = () => {
    if (translated) {
      navigator.clipboard.writeText(translated);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl relative">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Edit3 className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white">Type or Paste Text</h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <textarea
          rows={4}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste or type text here..."
          className="bg-slate-950 border border-slate-800 rounded-2xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none w-full resize-none"
        />

        <button
          onClick={handleTranslate}
          disabled={!text.trim() || isTranslating}
          className="w-full py-3 rounded-2xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-bold text-xs transition shadow-lg flex items-center justify-center gap-1.5"
        >
          {isTranslating ? (
            <Sparkles className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          <span>Translate to {targetLang}</span>
        </button>

        {translated && (
          <div className="p-4 bg-cyan-950/40 border border-cyan-500/30 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-cyan-300 uppercase">
                {targetLang} Translation
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => speakText(translated, targetLangSpeechTag)}
                  className="p-1.5 rounded-lg bg-cyan-600/30 text-cyan-200"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleCopy}
                  className="p-1.5 rounded-lg bg-cyan-600/30 text-cyan-200"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <p className="text-sm font-bold text-white">{translated}</p>
          </div>
        )}
      </div>
    </div>
  );
};
