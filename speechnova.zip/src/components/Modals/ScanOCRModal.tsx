import React, { useState, useRef } from "react";
import { X, Camera, Upload, Sparkles, Volume2, Copy, Check } from "lucide-react";
import { speakText } from "../../utils/speech";
import { SUPPORTED_LANGUAGES } from "../../data/languages";

interface ScanOCRModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetLang: string;
}

export const ScanOCRModal: React.FC<ScanOCRModalProps> = ({ isOpen, onClose, targetLang }) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [ocrResult, setOcrResult] = useState<{
    originalText: string;
    translatedText: string;
    detectedLanguage: string;
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const targetLangSpeechTag =
    SUPPORTED_LANGUAGES.find((l) => l.name === targetLang)?.speechTag || "en-US";

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setImagePreview(base64);
      processOCRScan(base64);
    };
    reader.readAsDataURL(file);
  };

  const processOCRScan = async (base64Data: string) => {
    setIsProcessing(true);
    setOcrResult(null);

    try {
      const res = await fetch("/api/ocr-scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64Data,
          targetLang,
        }),
      });

      const data = await res.json();
      setOcrResult(data);
    } catch (err) {
      console.error("OCR Error:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">Camera & Photo Translator</h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload / Capture Trigger */}
        <div className="text-center space-y-3">
          <input
            type="file"
            accept="image/*"
            capture="environment"
            ref={fileInputRef}
            onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
            className="hidden"
          />

          {!imagePreview ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-2xl p-8 cursor-pointer bg-slate-950/50 hover:bg-slate-950 transition flex flex-col items-center justify-center gap-2 text-slate-400"
            >
              <Upload className="w-8 h-8 text-emerald-400" />
              <p className="text-xs font-bold text-white">Upload photo or take a picture</p>
              <p className="text-[11px] text-slate-500">
                Extracts written text from signs, books, menus & documents
              </p>
            </div>
          ) : (
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 max-h-48">
              <img src={imagePreview} alt="Scan Preview" className="w-full object-cover" />
              <button
                onClick={() => {
                  setImagePreview(null);
                  setOcrResult(null);
                }}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-950/80 text-white hover:bg-slate-950"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Loading Spinner */}
        {isProcessing && (
          <div className="p-6 text-center space-y-2">
            <Sparkles className="w-8 h-8 text-emerald-400 animate-spin mx-auto" />
            <p className="text-xs font-bold text-slate-300">
              Scanning image text & translating to {targetLang}...
            </p>
          </div>
        )}

        {/* OCR Result Output */}
        {ocrResult && (
          <div className="space-y-3 pt-2">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase">
                Original Text ({ocrResult.detectedLanguage})
              </span>
              <p className="text-xs text-slate-300">{ocrResult.originalText}</p>
            </div>

            <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-emerald-300 uppercase">
                  Translated Text ({targetLang})
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => speakText(ocrResult.translatedText, targetLangSpeechTag)}
                    className="p-1 rounded-lg bg-emerald-600/30 text-emerald-300"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleCopy(ocrResult.translatedText)}
                    className="p-1 rounded-lg bg-emerald-600/30 text-emerald-300"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <p className="text-sm font-bold text-white leading-relaxed">
                {ocrResult.translatedText}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
