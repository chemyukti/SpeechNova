import React, { useState, useEffect } from "react";
import { AppSettings } from "../../types";
import { saveAppSettings } from "../../utils/storage";
import { speakText, getAvailableVoices } from "../../utils/speech";
import { getDictionaryCount, clearIndexedDBCache } from "../../utils/indexedDB";
import { X, Settings, Volume2, Volume1, VolumeX, Heart, Download, Database, Trash2, Check, Sparkles, Mic2, Mic, Sliders } from "lucide-react";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [speed, setSpeed] = useState(settings.speechSpeed);
  const [volume, setVolume] = useState(settings.speechVolume ?? 1.0);
  const [pitch, setPitch] = useState(settings.speechPitch);
  const [gender, setGender] = useState(settings.voiceGender);
  const [ttsEngine, setTtsEngine] = useState<'auto' | 'natural_hd' | 'webspeech'>(settings.ttsEngine || 'auto');
  const [selectedVoiceURI, setSelectedVoiceURI] = useState(settings.selectedVoiceURI || '');
  const [romantic, setRomantic] = useState(settings.romanticTone);
  const [micSensitivity, setMicSensitivity] = useState(settings.micSensitivity ?? 80);
  const [isPlayingTest, setIsPlayingTest] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [idbStats, setIdbStats] = useState<{ dictionaryCount: number; cacheCount: number }>({
    dictionaryCount: 0,
    cacheCount: 0,
  });
  const [cacheCleared, setCacheCleared] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSpeed(settings.speechSpeed);
      setVolume(settings.speechVolume ?? 1.0);
      setPitch(settings.speechPitch);
      setGender(settings.voiceGender);
      setTtsEngine(settings.ttsEngine || 'auto');
      setSelectedVoiceURI(settings.selectedVoiceURI || '');
      setRomantic(settings.romanticTone);
      setMicSensitivity(settings.micSensitivity ?? 80);

      getDictionaryCount().then(setIdbStats);
      setCacheCleared(false);

      // Populate available browser voices
      const voices = getAvailableVoices();
      setAvailableVoices(voices);

      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.onvoiceschanged = () => {
          setAvailableVoices(window.speechSynthesis.getVoices());
        };
      }
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleClearCache = async () => {
    await clearIndexedDBCache();
    const updatedStats = await getDictionaryCount();
    setIdbStats(updatedStats);
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 3000);
  };

  const handleTestSpeech = () => {
    setIsPlayingTest(true);
    speakText(
      "Hello! Welcome to SpeechNova live natural speech synthesis test.",
      "en-US",
      () => setIsPlayingTest(false),
      speed,
      volume
    );
  };

  const handleSave = () => {
    const updated = saveAppSettings({
      speechSpeed: speed,
      speechVolume: volume,
      speechPitch: pitch,
      voiceGender: gender,
      ttsEngine: ttsEngine,
      selectedVoiceURI: selectedVoiceURI,
      romanticTone: romantic,
      micSensitivity: micSensitivity,
    });
    onUpdateSettings(updated);
    onClose();
  };

  const speedPresets = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  const volumePresets = [0.0, 0.25, 0.5, 0.75, 1.0];
  const sensitivityPresets = [30, 50, 75, 90, 100];

  const getSensitivityLabel = (val: number) => {
    if (val <= 40) return "Low Gain (Quiet Room Noise Gate)";
    if (val <= 70) return "Balanced Input (Standard Indoor)";
    if (val <= 88) return "High Sensitivity (Classrooms & Hall)";
    return "Max Gain (Distance / Soft Speech)";
  };

  const renderVolumeIcon = () => {
    if (volume === 0) return <VolumeX className="w-4 h-4 text-rose-400" />;
    if (volume < 0.5) return <Volume1 className="w-4 h-4 text-purple-400" />;
    return <Volume2 className="w-4 h-4 text-purple-400" />;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-bold text-white">App Settings & Audio</h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white" id="btn-close-settings">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Engine Selection */}
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-indigo-950/60 border border-indigo-500/30 space-y-2.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
              <div>
                <p className="text-xs font-bold text-white">Voice Engine Quality</p>
                <p className="text-[10px] text-indigo-200/80">Choose voice generation method</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1.5 pt-1">
              <button
                type="button"
                onClick={() => setTtsEngine("auto")}
                className={`p-2 rounded-xl text-[11px] font-bold border transition text-center ${
                  ttsEngine === "auto"
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                Auto (Best Quality)
              </button>
              <button
                type="button"
                onClick={() => setTtsEngine("natural_hd")}
                className={`p-2 rounded-xl text-[11px] font-bold border transition text-center ${
                  ttsEngine === "natural_hd"
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                Natural HD Audio
              </button>
              <button
                type="button"
                onClick={() => setTtsEngine("webspeech")}
                className={`p-2 rounded-xl text-[11px] font-bold border transition text-center ${
                  ttsEngine === "webspeech"
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                Standard Device Voice
              </button>
            </div>
          </div>

          {/* Voice Picker Dropdown (for Web Speech mode) */}
          {availableVoices.length > 0 && (
            <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl space-y-2">
              <label className="text-xs text-slate-200 font-bold flex items-center gap-1.5">
                <Mic2 className="w-4 h-4 text-purple-400" />
                <span>Select Voice Persona ({availableVoices.length} voices found)</span>
              </label>
              <select
                value={selectedVoiceURI}
                onChange={(e) => setSelectedVoiceURI(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-500"
                id="select-voice-persona"
              >
                <option value="">Auto-Select Best Natural Voice</option>
                {availableVoices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name} ({v.lang}) {v.localService ? "[Offline]" : "[Neural HD]"}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Microphone Input Audio Sensitivity / Threshold Slider */}
          <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs text-slate-200 font-bold flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <span>Microphone Audio Sensitivity</span>
              </label>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {micSensitivity}%
              </span>
            </div>

            <p className="text-[10px] text-slate-400">
              Adjust input threshold to suppress background noise in lecture halls or noisy rooms:{" "}
              <span className="text-emerald-300 font-semibold">{getSensitivityLabel(micSensitivity)}</span>
            </p>

            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={micSensitivity}
              onChange={(e) => setMicSensitivity(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
              id="slider-mic-sensitivity"
            />

            {/* Quick Sensitivity Presets */}
            <div className="flex items-center justify-between gap-1 pt-1">
              {sensitivityPresets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setMicSensitivity(preset)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition border ${
                    Math.abs(micSensitivity - preset) < 3
                      ? "bg-emerald-600 text-white border-emerald-400 shadow-sm"
                      : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
                  }`}
                >
                  {preset}%
                </button>
              ))}
            </div>
          </div>

          {/* Text to Speech Volume Control Slider */}
          <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs text-slate-200 font-bold flex items-center gap-1.5">
                {renderVolumeIcon()}
                <span>Text-to-Speech Volume</span>
              </label>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {Math.round(volume * 100)}%
              </span>
            </div>

            <input
              type="range"
              min="0.0"
              max="1.0"
              step="0.05"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
              id="slider-speech-volume"
            />

            {/* Quick Volume Preset Buttons */}
            <div className="flex items-center justify-between gap-1 pt-1">
              {volumePresets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setVolume(preset)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition border ${
                    Math.abs(volume - preset) < 0.02
                      ? "bg-purple-600 text-white border-purple-400"
                      : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
                  }`}
                >
                  {preset === 0 ? "Mute" : `${Math.round(preset * 100)}%`}
                </button>
              ))}
            </div>
          </div>

          {/* Text to Speech Playback Speed Slider */}
          <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs text-slate-200 font-bold flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-purple-400" />
                <span>Text-to-Speech Speed</span>
              </label>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {speed.toFixed(2)}x
              </span>
            </div>

            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.05"
              value={speed}
              onChange={(e) => setSpeed(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
              id="slider-speech-speed"
            />

            {/* Quick Speed Preset Buttons */}
            <div className="flex items-center justify-between gap-1 pt-1">
              {speedPresets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setSpeed(preset)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition border ${
                    Math.abs(speed - preset) < 0.02
                      ? "bg-purple-600 text-white border-purple-400"
                      : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
                  }`}
                >
                  {preset}x
                </button>
              ))}
            </div>

            {/* Test Audio Button */}
            <button
              type="button"
              onClick={handleTestSpeech}
              className="w-full mt-2 py-2 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 border border-purple-500/30 text-purple-300 hover:text-white text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
              id="btn-test-speed"
            >
              <Volume2 className={`w-4 h-4 ${isPlayingTest ? "animate-bounce text-purple-400" : ""}`} />
              <span>{isPlayingTest ? "Playing Natural HD Audio..." : "Test Voice Output Now"}</span>
            </button>
          </div>

          {/* Speech Pitch */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-300 font-bold mb-1">
              <span>Speech Pitch</span>
              <span className="text-purple-400">{pitch.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.5"
              step="0.1"
              value={pitch}
              onChange={(e) => setPitch(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          {/* Voice Gender */}
          <div>
            <label className="text-xs text-slate-300 font-bold block mb-1">Voice Preference</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setGender("female")}
                className={`py-2 text-xs font-bold rounded-xl border transition ${
                  gender === "female"
                    ? "bg-purple-600 text-white border-purple-400"
                    : "bg-slate-950 text-slate-400 border-slate-800"
                }`}
              >
                Female Voice
              </button>
              <button
                type="button"
                onClick={() => setGender("male")}
                className={`py-2 text-xs font-bold rounded-xl border transition ${
                  gender === "male"
                    ? "bg-purple-600 text-white border-purple-400"
                    : "bg-slate-950 text-slate-400 border-slate-800"
                }`}
              >
                Male Voice
              </button>
            </div>
          </div>

          {/* Romantic Tone */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-400" />
              <div>
                <p className="text-xs font-bold text-white">Romantic / Warm Tone</p>
                <p className="text-[10px] text-slate-400">
                  Translates messages with warm, affectionate expressions
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={romantic}
              onChange={(e) => setRomantic(e.target.checked)}
              className="w-4 h-4 accent-rose-500 cursor-pointer"
            />
          </div>

          {/* Offline Storage & Memory Manager */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <div>
                  <p className="text-xs font-bold text-white">Offline Vocabulary & Memory</p>
                  <p className="text-[10px] text-slate-400">
                    Saved dictionary words and translation memory
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Ready
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
              <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-2 text-center">
                <span className="text-[10px] text-slate-400 block">Saved Vocabulary</span>
                <span className="font-extrabold text-indigo-300">{idbStats.dictionaryCount} words</span>
              </div>
              <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-2 text-center">
                <span className="text-[10px] text-slate-400 block">Saved Memory</span>
                <span className="font-extrabold text-indigo-300">{idbStats.cacheCount} phrases</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleClearCache}
              disabled={idbStats.cacheCount === 0}
              className="w-full mt-1 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-300 hover:text-white text-xs font-bold transition flex items-center justify-center gap-1.5 border border-slate-800"
              id="btn-clear-idb-cache"
            >
              {cacheCleared ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Memory Cleared!</span>
                </>
              ) : (
                <>
                  <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                  <span>Refresh Saved Memory</span>
                </>
              )}
            </button>
          </div>

          {/* Offline Language Status Guide */}
          <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 space-y-2 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <Download className="w-4 h-4" />
              <span>Offline Language & Speech Packs</span>
            </div>
            <p className="text-indigo-200/80 leading-relaxed text-[11px]">
              SpeechNova supports on-device speech translation. Language models and voice recognition packs are automatically cached for fast offline access.
            </p>
          </div>
        </div>

        <button
          onClick={handleSave}
          className="w-full py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition shadow-lg"
          id="btn-save-settings"
        >
          Save Settings
        </button>
      </div>
    </div>
  );
};
