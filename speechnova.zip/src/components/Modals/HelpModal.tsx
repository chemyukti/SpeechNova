import React from "react";
import { X, HelpCircle, Mic, BookOpen, MessageSquare, Users, Camera, Settings, WifiOff, Smartphone } from "lucide-react";

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold text-white">How to Use SpeechNova</h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <Mic className="w-4 h-4 text-indigo-400" />
              <span>Real-Time Voice Translation</span>
            </div>
            <p className="text-slate-400">
              Select source and target languages on the Home tab. Tap the microphone to record speech, or type text to translate instantly with audio playback.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <span>Learn Alphabets & Pronunciation</span>
            </div>
            <p className="text-slate-400">
              Explore 45 language scripts (Devanagari, Bengali, Cyrillic, Hiragana, etc.). Practice saying words with syllable-level pronunciation coaching.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <Users className="w-4 h-4 text-indigo-400" />
              <span>Face-to-Face Conversation Mode</span>
            </div>
            <p className="text-slate-400">
              Split-screen layout for 2-way live conversations. Flip the top card 180° for partners sitting across a table.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <Camera className="w-4 h-4 text-indigo-400" />
              <span>Camera Text Scan (OCR)</span>
            </div>
            <p className="text-slate-400">
              Upload or snap a photo of signs, menus, or books. SpeechNova extracts and translates text instantly.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <WifiOff className="w-4 h-4 text-emerald-400" />
              <span>Offline Translation & Voice Synthesis</span>
            </div>
            <p className="text-slate-400">
              Works offline without active internet using client-side dictionary matching, natural voice synthesis, and saved translation memory.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <Smartphone className="w-4 h-4 text-purple-400" />
              <span>Mobile App & Offline Ready</span>
            </div>
            <p className="text-slate-400">
              Includes pre-configured mobile app manifest and native bridge integration for full on-device offline usage.
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition shadow-lg"
        >
          Got it!
        </button>
      </div>
    </div>
  );
};
