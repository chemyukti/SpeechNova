import React from "react";
import { Sparkles, HelpCircle, Edit3, Camera, Star, Settings, ArrowLeftRight, GraduationCap } from "lucide-react";

interface HeaderProps {
  onOpenHelp: () => void;
  onOpenTypePaste: () => void;
  onOpenScanOCR: () => void;
  onOpenFavorites: () => void;
  onOpenSettings: () => void;
  onOpenLectureModal: () => void;
  favoriteCount: number;
  sourceLang?: string;
  targetLang?: string;
  onSwapLanguages?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenHelp,
  onOpenTypePaste,
  onOpenScanOCR,
  onOpenFavorites,
  onOpenSettings,
  onOpenLectureModal,
  favoriteCount,
  sourceLang,
  targetLang,
  onSwapLanguages,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 shadow-md">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Logo Branding */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Sparkles className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-indigo-100 to-indigo-300 bg-clip-text text-transparent">
                SpeechNova
              </h1>
              <span className="text-[10px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                PRO
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Speech Translation & Language Learning
            </p>
          </div>
        </div>

        {/* Dedicated Quick Swap Language Badge in Header */}
        {onSwapLanguages && sourceLang && targetLang && (
          <div className="flex items-center gap-1.5 bg-slate-800/90 px-3 py-1.5 rounded-xl border border-indigo-500/30 shadow-inner">
            <span className="text-xs font-bold text-indigo-300 max-w-[80px] sm:max-w-[110px] truncate" title={`Source: ${sourceLang}`}>
              {sourceLang}
            </span>
            <button
              onClick={onSwapLanguages}
              title={`Swap languages (${sourceLang} ↔ ${targetLang})`}
              className="p-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/60 text-indigo-200 hover:text-white transition group border border-indigo-500/40"
              id="btn-header-swap-lang"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-300" />
            </button>
            <span className="text-xs font-bold text-indigo-300 max-w-[80px] sm:max-w-[110px] truncate" title={`Target: ${targetLang}`}>
              {targetLang}
            </span>
          </div>
        )}

        {/* Quick Shortcut Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Lecture & Seminar Studio Button */}
          <button
            onClick={onOpenLectureModal}
            title="Record & Translate Lectures, Seminars & Teaching (Export DOC)"
            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs transition border border-indigo-400/40 shadow-md flex items-center gap-1.5"
            id="btn-header-lecture-studio"
          >
            <GraduationCap className="w-4 h-4 sm:w-4 sm:h-4 text-amber-300" />
            <span className="hidden md:inline">Record Lecture</span>
          </button>

          {/* Help Button */}
          <button
            onClick={onOpenHelp}
            title="How to Use SpeechNova"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700/60"
            id="btn-header-help"
          >
            <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-400" />
          </button>

          {/* Type/Paste Text Translate */}
          <button
            onClick={onOpenTypePaste}
            title="Type or Paste Text"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700/60"
            id="btn-header-type"
          >
            <Edit3 className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
          </button>

          {/* Camera Scan */}
          <button
            onClick={onOpenScanOCR}
            title="Scan & Translate Text with Camera"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700/60 relative"
            id="btn-header-ocr"
          >
            <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" />
          </button>

          {/* Favorites Saved Translations */}
          <button
            onClick={onOpenFavorites}
            title="Saved Favorites"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700/60 relative"
            id="btn-header-favorites"
          >
            <Star className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            {favoriteCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-[10px] font-bold text-slate-950 flex items-center justify-center">
                {favoriteCount}
              </span>
            )}
          </button>

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            title="App Settings"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700/60"
            id="btn-header-settings"
          >
            <Settings className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
