import React from "react";
import { Mic, BookOpen, MessageSquare, Users, Award, GraduationCap } from "lucide-react";

export type TabType = "home" | "lecture" | "learn" | "phrases" | "face2face" | "quiz";

interface NavigationProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onSelectTab }) => {
  const tabs = [
    { id: "home" as TabType, label: "Home", icon: Mic },
    { id: "lecture" as TabType, label: "Lecture", icon: GraduationCap },
    { id: "learn" as TabType, label: "Learn", icon: BookOpen },
    { id: "phrases" as TabType, label: "Phrases", icon: MessageSquare },
    { id: "face2face" as TabType, label: "Face2Face", icon: Users },
    { id: "quiz" as TabType, label: "Quiz", icon: Award },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-2 shadow-2xl">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? "text-indigo-400 font-bold bg-indigo-500/15"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              id={`tab-btn-${tab.id}`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? "scale-110 text-indigo-400" : ""}`} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
                )}
              </div>
              <span className="text-[11px] font-medium tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
