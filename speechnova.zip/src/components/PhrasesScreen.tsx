import React, { useState } from "react";
import { PHRASE_CATEGORIES } from "../data/phrases";
import { SUPPORTED_LANGUAGES } from "../data/languages";
import { speakText } from "../utils/speech";
import { translateOfflineAsync } from "../utils/offlineTranslator";
import {
  MessageSquare,
  Volume2,
  Search,
  Plane,
  Utensils,
  Hotel,
  Bus,
  ShoppingBag,
  AlertTriangle,
  MessageCircle,
  Copy,
  Check,
  Sparkles
} from "lucide-react";

interface PhrasesScreenProps {
  targetLang: string;
}

const categoryIcons: Record<string, any> = {
  MessageCircle,
  Plane,
  Utensils,
  Hotel,
  Bus,
  ShoppingBag,
  AlertTriangle,
};

export const PhrasesScreen: React.FC<PhrasesScreenProps> = ({ targetLang }) => {
  const [selectedCatId, setSelectedCatId] = useState<string>("daily");
  const [searchQuery, setSearchQuery] = useState("");
  const [translationsCache, setTranslationsCache] = useState<Record<string, string>>({});
  const [loadingPhraseId, setLoadingPhraseId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const targetLangSpeechTag =
    SUPPORTED_LANGUAGES.find((l) => l.name === targetLang)?.speechTag || "es-ES";

  // Translate phrase on demand
  const handleTranslatePhrase = async (phraseId: string, englishText: string) => {
    const cacheKey = `${phraseId}_${targetLang}`;
    if (translationsCache[cacheKey]) {
      speakText(translationsCache[cacheKey], targetLangSpeechTag);
      return;
    }

    setLoadingPhraseId(phraseId);
    try {
      const res = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: englishText,
          sourceLang: "English",
          targetLang,
        }),
      });
      const data = await res.json();
      const translated = data.translatedText || englishText;

      setTranslationsCache((prev) => ({ ...prev, [cacheKey]: translated }));
      speakText(translated, targetLangSpeechTag);
    } catch (err) {
      console.warn("Server translate endpoint failed, using IndexedDB offline translation:", err);
      const offlineRes = await translateOfflineAsync(englishText, "English", targetLang);
      const translated = offlineRes.translatedText;
      setTranslationsCache((prev) => ({ ...prev, [cacheKey]: translated }));
      speakText(translated, targetLangSpeechTag);
    } finally {
      setLoadingPhraseId(null);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const activeCategory = PHRASE_CATEGORIES.find((c) => c.id === selectedCatId) || PHRASE_CATEGORIES[0];

  // Search filter
  const filteredPhrases = activeCategory.phrases.filter((p) =>
    p.english.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="pb-24 pt-4 px-4 max-w-3xl mx-auto space-y-5">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-900 via-slate-900 to-slate-950 border border-purple-500/30 rounded-3xl p-5 shadow-xl flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-purple-400" />
            Travel & Essential Phrases
          </h1>
          <p className="text-xs text-purple-200/80 mt-1">
            Tap any phrase to instantly translate into{" "}
            <span className="text-amber-300 font-bold">{targetLang}</span> & play audio
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search travel phrases..."
          className="bg-slate-900 border border-slate-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none w-full"
        />
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {PHRASE_CATEGORIES.map((cat) => {
          const IconComp = categoryIcons[cat.iconName] || MessageSquare;
          const isSelected = selectedCatId === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCatId(cat.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 border ${
                isSelected
                  ? "bg-purple-600 text-white border-purple-400 shadow-lg"
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
              }`}
            >
              <IconComp className="w-3.5 h-3.5" />
              {cat.name}
            </button>
          );
        })}
      </div>

      {/* Phrase Cards Stream */}
      <div className="space-y-3">
        {filteredPhrases.length === 0 ? (
          <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-8 text-center text-slate-500">
            No phrases found matching "{searchQuery}".
          </div>
        ) : (
          filteredPhrases.map((phrase) => {
            const cacheKey = `${phrase.id}_${targetLang}`;
            const cachedTranslation = translationsCache[cacheKey];
            const isLoading = loadingPhraseId === phrase.id;
            const isCopied = copiedId === phrase.id;

            return (
              <div
                key={phrase.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md hover:border-slate-700 transition"
              >
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-white">{phrase.english}</h3>
                  {cachedTranslation && (
                    <p className="text-xs font-bold text-purple-300 bg-purple-950/40 px-2.5 py-1 rounded-lg border border-purple-500/20 inline-block">
                      {cachedTranslation}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  {cachedTranslation && (
                    <button
                      onClick={() => handleCopy(phrase.id, cachedTranslation)}
                      className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition text-xs"
                      title="Copy Phrase"
                    >
                      {isCopied ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  )}

                  <button
                    onClick={() => handleTranslatePhrase(phrase.id, phrase.english)}
                    disabled={isLoading}
                    className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-lg flex items-center gap-1.5 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <Sparkles className="w-4 h-4 animate-spin" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                    <span>{cachedTranslation ? "Listen" : "Translate & Speak"}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
