/**
 * Utility to filter out filler words, hesitation sounds, stuttering repetitions,
 * and conversational speech artifacts from recognized speech transcripts in real-time.
 */

export function filterFillerWords(text: string, languageTag?: string): string {
  if (!text || typeof text !== "string") return "";

  let cleaned = text;

  // 1. Multilingual Hesitation Sounds & Vocal Fillers (Case-Insensitive)
  // Matches standalone vocal pause sounds: um, umm, uh, uhh, er, err, ah, ahh, hmm, hmmm, mhm, huh, euh, äh, ehm
  cleaned = cleaned.replace(
    /\b(u+m+|u+h+|e+r+|a+h+|h+m+|m+h+m+|h+u+h+|e+u+h+|ä+h+|ä+h+m+)\b/gi,
    ""
  );

  // 2. Common Conversational Filler Phrases
  const fillerPatterns = [
    /\b(you know)\b/gi,
    /\b(i mean)\b/gi,
    /\b(sort of)\b/gi,
    /\b(kind of)\b/gi,
    /\b(so yeah)\b/gi,
    /\b(basically)\b/gi,
    /\b(actually)\b/gi,
    /\b(literally)\b/gi,
    /\b(anyways?)\b/gi,
    // "like" when used as an explicit speech filler (e.g. ", like," or "like um" or leading/trailing filler)
    /(?:,\s*like\s*,|^\s*like\s*,|,\s*like\s+|\b\s+like\s*(?=,\s*|\s+(?:um|uh|you know|i mean|basically|actually)\b))/gi,
    // Spanish fillers
    /\b(o sea)\b/gi,
    /\b(estee?)\b/gi,
    // French fillers
    /\b(du coup)\b/gi,
    // German fillers
    /\b(sozusagen)\b/gi,
  ];

  // If Hindi or Devanagari script is present or selected
  if (languageTag?.startsWith("hi") || /[\u0900-\u097F]/.test(cleaned)) {
    cleaned = cleaned.replace(/\b(मतलब|यार|अरे|वैसे)\b/g, "");
  }

  for (const pattern of fillerPatterns) {
    cleaned = cleaned.replace(pattern, "");
  }

  // 3. Stuttering / Repeated Word Suppression (e.g., "I I think" -> "I think", "the the book" -> "the book")
  cleaned = cleaned.replace(/\b(\w+)\s+\1\b/gi, "$1");

  // 4. Clean up Punctuation and Whitespace Artifacts
  cleaned = cleaned
    .replace(/\s*,\s*,/g, ",")       // Double commas
    .replace(/^\s*,\s*/, "")          // Leading comma
    .replace(/\s*,\s*\./g, ".")       // Comma before period
    .replace(/\s{2,}/g, " ")          // Multiple spaces
    .trim();

  // 5. Preserve Sentence Capitalization
  if (cleaned.length > 0 && text.length > 0 && text.charAt(0) === text.charAt(0).toUpperCase()) {
    cleaned = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
  }

  return cleaned;
}
