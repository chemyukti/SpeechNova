// IndexedDB Local Storage Module for SpeechNova
// Manages local dictionary entries and translation cache for offline functionality.

export interface IndexedDBDictionaryEntry {
  id?: string;
  sourceLang: string;
  targetLang: string;
  sourceText: string;
  translatedText: string;
  romanization?: string;
  category?: string;
  timestamp: number;
}

export interface CachedTranslation {
  cacheKey: string; // `${sourceLang}:${targetLang}:${sourceText.toLowerCase().trim()}`
  sourceLang: string;
  targetLang: string;
  sourceText: string;
  translatedText: string;
  detectedLanguage?: string;
  romanization?: string;
  timestamp: number;
}

const DB_NAME = "SpeechNovaDB";
const DB_VERSION = 1;

export const STORES = {
  DICTIONARY: "dictionary",
  TRANSLATION_CACHE: "translationCache",
};

let dbPromise: Promise<IDBDatabase> | null = null;

export function getDB(): Promise<IDBDatabase> {
  if (typeof window === "undefined" || !("indexedDB" in window)) {
    return Promise.reject(new Error("IndexedDB is not supported in this browser/environment."));
  }

  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
        const db = request.result;

        // Dictionary store
        if (!db.objectStoreNames.contains(STORES.DICTIONARY)) {
          const dictStore = db.createObjectStore(STORES.DICTIONARY, {
            keyPath: "id",
          });
          dictStore.createIndex("sourceLang", "sourceLang", { unique: false });
          dictStore.createIndex("targetLang", "targetLang", { unique: false });
          dictStore.createIndex("sourceText", "sourceText", { unique: false });
        }

        // Translation Cache store
        if (!db.objectStoreNames.contains(STORES.TRANSLATION_CACHE)) {
          const cacheStore = db.createObjectStore(STORES.TRANSLATION_CACHE, {
            keyPath: "cacheKey",
          });
          cacheStore.createIndex("timestamp", "timestamp", { unique: false });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        console.error("IndexedDB open error:", request.error);
        reject(request.error);
      };
    });
  }

  return dbPromise;
}

// Build standard cache key string
export function buildCacheKey(sourceLang: string, targetLang: string, sourceText: string): string {
  return `${sourceLang.toLowerCase().trim()}:${targetLang.toLowerCase().trim()}:${sourceText.toLowerCase().trim()}`;
}

// ── TRANSLATION CACHE METHODS ──

export async function getTranslationFromCache(
  sourceLang: string,
  targetLang: string,
  sourceText: string
): Promise<CachedTranslation | null> {
  try {
    const db = await getDB();
    const key = buildCacheKey(sourceLang, targetLang, sourceText);
    return new Promise((resolve) => {
      const tx = db.transaction(STORES.TRANSLATION_CACHE, "readonly");
      const store = tx.objectStore(STORES.TRANSLATION_CACHE);
      const req = store.get(key);

      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function saveTranslationToCache(entry: Omit<CachedTranslation, "cacheKey" | "timestamp">): Promise<void> {
  try {
    const db = await getDB();
    const cacheKey = buildCacheKey(entry.sourceLang, entry.targetLang, entry.sourceText);
    const item: CachedTranslation = {
      ...entry,
      cacheKey,
      timestamp: Date.now(),
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.TRANSLATION_CACHE, "readwrite");
      const store = tx.objectStore(STORES.TRANSLATION_CACHE);
      const req = store.put(item);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn("Failed to save translation to IndexedDB cache:", err);
  }
}

// ── DICTIONARY STORE METHODS ──

export async function addWordToLocalDictionary(
  entry: Omit<IndexedDBDictionaryEntry, "id" | "timestamp">
): Promise<string> {
  const db = await getDB();
  const id = `${entry.sourceLang}:${entry.targetLang}:${entry.sourceText.toLowerCase().trim()}`;
  const fullEntry: IndexedDBDictionaryEntry = {
    ...entry,
    id,
    timestamp: Date.now(),
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.DICTIONARY, "readwrite");
    const store = tx.objectStore(STORES.DICTIONARY);
    const req = store.put(fullEntry);

    req.onsuccess = () => resolve(id);
    req.onerror = () => reject(req.error);
  });
}

export async function lookupLocalDictionary(
  sourceLang: string,
  targetLang: string,
  sourceText: string
): Promise<IndexedDBDictionaryEntry | null> {
  try {
    const db = await getDB();
    const cleanText = sourceText.toLowerCase().trim();
    const id = `${sourceLang}:${targetLang}:${cleanText}`;

    // Direct key lookup first
    const directEntry = await new Promise<IndexedDBDictionaryEntry | null>((resolve) => {
      const tx = db.transaction(STORES.DICTIONARY, "readonly");
      const store = tx.objectStore(STORES.DICTIONARY);
      const req = store.get(id);

      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });

    if (directEntry) return directEntry;

    // Search via cursor scan for case-insensitive / language match
    return new Promise((resolve) => {
      const tx = db.transaction(STORES.DICTIONARY, "readonly");
      const store = tx.objectStore(STORES.DICTIONARY);
      const req = store.openCursor();

      req.onsuccess = () => {
        const cursor = req.result;
        if (cursor) {
          const val = cursor.value as IndexedDBDictionaryEntry;
          if (
            val.sourceText.toLowerCase().trim() === cleanText &&
            (sourceLang === "Auto Detect" || val.sourceLang.toLowerCase() === sourceLang.toLowerCase()) &&
            val.targetLang.toLowerCase() === targetLang.toLowerCase()
          ) {
            resolve(val);
            return;
          }
          cursor.continue();
        } else {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function getDictionaryCount(): Promise<{ dictionaryCount: number; cacheCount: number }> {
  try {
    const db = await getDB();

    const dictCount = await new Promise<number>((res) => {
      const tx = db.transaction(STORES.DICTIONARY, "readonly");
      const req = tx.objectStore(STORES.DICTIONARY).count();
      req.onsuccess = () => res(req.result);
      req.onerror = () => res(0);
    });

    const cacheCount = await new Promise<number>((res) => {
      const tx = db.transaction(STORES.TRANSLATION_CACHE, "readonly");
      const req = tx.objectStore(STORES.TRANSLATION_CACHE).count();
      req.onsuccess = () => res(req.result);
      req.onerror = () => res(0);
    });

    return { dictionaryCount: dictCount, cacheCount };
  } catch {
    return { dictionaryCount: 0, cacheCount: 0 };
  }
}

export async function getAllCachedTranslations(): Promise<CachedTranslation[]> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORES.TRANSLATION_CACHE, "readonly");
      const req = tx.objectStore(STORES.TRANSLATION_CACHE).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function clearIndexedDBCache(): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.TRANSLATION_CACHE, "readwrite");
      const req = tx.objectStore(STORES.TRANSLATION_CACHE).clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.error("Error clearing translation cache:", e);
  }
}

// Seed common dictionary into IndexedDB on initialization
export async function seedInitialDictionary(entries: Omit<IndexedDBDictionaryEntry, "id" | "timestamp">[]): Promise<number> {
  try {
    const db = await getDB();
    let addedCount = 0;

    for (const entry of entries) {
      const id = `${entry.sourceLang}:${entry.targetLang}:${entry.sourceText.toLowerCase().trim()}`;
      await new Promise<void>((resolve) => {
        const tx = db.transaction(STORES.DICTIONARY, "readwrite");
        const store = tx.objectStore(STORES.DICTIONARY);
        const req = store.put({
          ...entry,
          id,
          timestamp: Date.now(),
        });
        req.onsuccess = () => {
          addedCount++;
          resolve();
        };
        req.onerror = () => resolve();
      });
    }

    return addedCount;
  } catch (err) {
    console.warn("Could not seed initial dictionary to IndexedDB:", err);
    return 0;
  }
}
