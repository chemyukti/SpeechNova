import { getAppSettings } from "./storage";
import { filterFillerWords } from "./textCleaner";

let currentAudio: HTMLAudioElement | null = null;

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
  return window.speechSynthesis.getVoices();
}

// Helper to find the highest quality, most natural human voice available for a language tag
function findBestHumanVoice(
  voices: SpeechSynthesisVoice[],
  languageTag: string,
  preferredGender: "female" | "male" = "female",
  preferredVoiceURI?: string
): SpeechSynthesisVoice | null {
  if (!voices || voices.length === 0) return null;

  // 1. Exact user preferred voice match
  if (preferredVoiceURI) {
    const selected = voices.find((v) => v.voiceURI === preferredVoiceURI);
    if (selected) return selected;
  }

  const langBase = languageTag.split("-")[0].toLowerCase();

  // Filter voices matching language tag or language base code
  const matchingVoices = voices.filter(
    (v) =>
      v.lang.toLowerCase() === languageTag.toLowerCase() ||
      v.lang.toLowerCase().replace("_", "-").startsWith(langBase)
  );

  if (matchingVoices.length === 0) return null;

  // Score candidate voices based on quality keywords (Natural, Neural, Premium, Google, Siri, Enhanced, Microsoft)
  const scoreVoice = (v: SpeechSynthesisVoice): number => {
    let score = 0;
    const name = v.name.toLowerCase();

    if (name.includes("natural") || name.includes("neural") || name.includes("online")) score += 60;
    if (name.includes("google")) score += 50;
    if (name.includes("enhanced") || name.includes("premium")) score += 40;
    if (name.includes("siri") || name.includes("samantha") || name.includes("victoria")) score += 30;
    if (name.includes("microsoft") || name.includes("aria") || name.includes("swara")) score += 25;
    if (v.localService === false) score += 20; // Network neural voices sound significantly more realistic

    // Gender preference matching
    if (preferredGender === "female") {
      if (
        name.includes("female") ||
        name.includes("zira") ||
        name.includes("samantha") ||
        name.includes("victoria") ||
        name.includes("karen") ||
        name.includes("swara") ||
        name.includes("aria")
      ) score += 15;
    } else {
      if (
        name.includes("male") ||
        name.includes("david") ||
        name.includes("george") ||
        name.includes("alex") ||
        name.includes("guy") ||
        name.includes("madhur")
      ) score += 15;
    }

    if (v.lang.toLowerCase() === languageTag.toLowerCase()) score += 10;

    return score;
  };

  matchingVoices.sort((a, b) => scoreVoice(b) - scoreVoice(a));
  return matchingVoices[0] || null;
}

// Pre-warm voices list asynchronously for Web Speech API
let cachedVoices: SpeechSynthesisVoice[] = [];

if (typeof window !== "undefined" && "speechSynthesis" in window) {
  const updateVoices = () => {
    cachedVoices = window.speechSynthesis.getVoices();
  };
  updateVoices();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = updateVoices;
  }
}

// Speak via Web Speech API
function speakWithWebSpeech(
  cleanText: string,
  languageTag: string,
  onEnd?: () => void,
  customSpeed?: number,
  customVolume?: number
) {
  if (!("speechSynthesis" in window)) {
    if (onEnd) onEnd();
    return;
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(cleanText);
  const settings = getAppSettings();

  utterance.rate = customSpeed !== undefined ? customSpeed : (settings.speechSpeed || 0.95);
  utterance.pitch = settings.speechPitch || 1.0;
  utterance.volume = customVolume !== undefined ? customVolume : (settings.speechVolume !== undefined ? settings.speechVolume : 1.0);

  const voices = cachedVoices.length > 0 ? cachedVoices : window.speechSynthesis.getVoices();
  const bestVoice = findBestHumanVoice(voices, languageTag, settings.voiceGender, settings.selectedVoiceURI);

  if (bestVoice) {
    utterance.voice = bestVoice;
  }
  utterance.lang = languageTag;

  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = onEnd;
  }

  window.speechSynthesis.speak(utterance);
}

// Speak via Natural HD Online Audio Stream
function speakWithNaturalStream(
  cleanText: string,
  languageTag: string,
  onEnd?: () => void,
  customSpeed?: number,
  customVolume?: number
): boolean {
  try {
    if (typeof window === "undefined" || !navigator.onLine) {
      return false; // Fallback to Web Speech if offline
    }

    const encodedText = encodeURIComponent(cleanText.slice(0, 350));
    const audioUrl = `/api/tts?text=${encodedText}&lang=${encodeURIComponent(languageTag)}`;

    stopSpeech();

    const audio = new Audio(audioUrl);
    currentAudio = audio;

    const settings = getAppSettings();
    const speed = customSpeed !== undefined ? customSpeed : (settings.speechSpeed || 1.0);
    const volume = customVolume !== undefined ? customVolume : (settings.speechVolume !== undefined ? settings.speechVolume : 1.0);

    audio.playbackRate = Math.max(0.75, Math.min(1.5, speed));
    audio.volume = Math.max(0, Math.min(1.0, volume));

    audio.onended = () => {
      currentAudio = null;
      if (onEnd) onEnd();
    };

    audio.onerror = () => {
      currentAudio = null;
      // Fallback on error
      speakWithWebSpeech(cleanText, languageTag, onEnd, customSpeed, customVolume);
    };

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {
        currentAudio = null;
        speakWithWebSpeech(cleanText, languageTag, onEnd, customSpeed, customVolume);
      });
    }

    return true;
  } catch {
    return false;
  }
}

// Master Voice Synthesis helper
export const speakText = (
  text: string,
  languageTag: string,
  onEnd?: () => void,
  customSpeed?: number,
  customVolume?: number
) => {
  stopSpeech();

  // Clean out emojis, brackets, and parentheticals to prevent robotic pronunciation of punctuation
  let cleanTextToSpeak = text
    .replace(/\[.*?\]/g, "")
    .replace(/\(.*?\)/g, "")
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "")
    .trim() || text;

  if (!cleanTextToSpeak) {
    if (onEnd) onEnd();
    return;
  }

  const settings = getAppSettings();
  const engine = settings.ttsEngine || "auto";

  if (engine === "natural_hd") {
    const success = speakWithNaturalStream(cleanTextToSpeak, languageTag, onEnd, customSpeed, customVolume);
    if (!success) {
      speakWithWebSpeech(cleanTextToSpeak, languageTag, onEnd, customSpeed, customVolume);
    }
  } else if (engine === "webspeech") {
    speakWithWebSpeech(cleanTextToSpeak, languageTag, onEnd, customSpeed, customVolume);
  } else {
    // "auto" mode: Try Natural HD Server Stream first if online, else WebSpeech
    if (navigator.onLine) {
      speakWithNaturalStream(cleanTextToSpeak, languageTag, onEnd, customSpeed, customVolume);
    } else {
      speakWithWebSpeech(cleanTextToSpeak, languageTag, onEnd, customSpeed, customVolume);
    }
  }
};

export const stopSpeech = () => {
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.currentTime = 0;
    } catch {}
    currentAudio = null;
  }

  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
};

// Web Speech API Recognition Creator
export interface SpeechRecognitionResultHandler {
  onResult: (transcript: string, isFinal: boolean) => void;
  onError: (error: string) => void;
  onEnd: () => void;
}

export const createSpeechRecognizer = (
  languageTag: string,
  handlers: SpeechRecognitionResultHandler
) => {
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    handlers.onError("Speech recognition is not supported in this browser.");
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = languageTag;

  recognition.onresult = (event: any) => {
    let interim = "";
    let final = "";

    for (let i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        final += event.results[i][0].transcript;
      } else {
        interim += event.results[i][0].transcript;
      }
    }

    const currentText = final || interim;
    if (currentText) {
      const cleanedText = filterFillerWords(currentText, languageTag);
      handlers.onResult(cleanedText || currentText, !!final);
    }
  };

  recognition.onerror = (event: any) => {
    handlers.onError(event.error || "Speech recognition error");
  };

  recognition.onend = () => {
    handlers.onEnd();
  };

  return recognition;
};
