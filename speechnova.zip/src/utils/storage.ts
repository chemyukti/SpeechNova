import { AppSettings, CustomWord, Learner, TranslationMessage } from "../types";

const KEYS = {
  CURRENT_LEARNER: "speechnova_current_learner",
  LEARNERS: "speechnova_learners",
  CUSTOM_WORDS: "speechnova_custom_words",
  FAVORITES: "speechnova_favorites",
  SETTINGS: "speechnova_settings",
  HISTORY: "speechnova_history",
};

export const DEFAULT_SETTINGS: AppSettings = {
  speechSpeed: 1.0,
  speechVolume: 1.0,
  speechPitch: 1.0,
  voiceGender: "female",
  ttsEngine: "auto",
  selectedVoiceURI: "",
  romanticTone: false,
  practiceMode: false,
  offlineTipDismissed: false,
  micSensitivity: 80,
};

export const getAppSettings = (): AppSettings => {
  try {
    const raw = localStorage.getItem(KEYS.SETTINGS);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveAppSettings = (settings: Partial<AppSettings>): AppSettings => {
  const current = getAppSettings();
  const updated = { ...current, ...settings };
  localStorage.setItem(KEYS.SETTINGS, JSON.stringify(updated));
  return updated;
};

// Learner & Leaderboard Management
export const getCurrentLearner = (): string => {
  return localStorage.getItem(KEYS.CURRENT_LEARNER) || "Learner 1";
};

export const setCurrentLearner = (name: string): void => {
  const clean = name.trim().slice(0, 20) || "Learner";
  localStorage.setItem(KEYS.CURRENT_LEARNER, clean);
  
  const learners = getLeaderboard();
  if (!learners.some((l) => l.name.toLowerCase() === clean.toLowerCase())) {
    saveLeaderboard([...learners, { name: clean, points: 0 }]);
  }
};

export const getLeaderboard = (): Learner[] => {
  try {
    const raw = localStorage.getItem(KEYS.LEARNERS);
    const list: Learner[] = raw ? JSON.parse(raw) : [];
    if (list.length === 0) {
      return [
        { name: "Learner 1", points: 120 },
        { name: "Aarav", points: 80 },
        { name: "Elena", points: 50 },
      ];
    }
    return list.sort((a, b) => b.points - a.points);
  } catch {
    return [{ name: "Learner 1", points: 0 }];
  }
};

export const saveLeaderboard = (learners: Learner[]): void => {
  localStorage.setItem(KEYS.LEARNERS, JSON.stringify(learners));
};

export const addPoints = (points: number): number => {
  const name = getCurrentLearner();
  const learners = getLeaderboard();
  let newTotal = points;

  const updated = learners.map((l) => {
    if (l.name.toLowerCase() === name.toLowerCase()) {
      newTotal = Math.max(0, l.points + points);
      return { ...l, points: newTotal };
    }
    return l;
  });

  if (!learners.some((l) => l.name.toLowerCase() === name.toLowerCase())) {
    updated.push({ name, points: Math.max(0, points) });
    newTotal = points;
  }

  saveLeaderboard(updated);
  return newTotal;
};

// Custom Words
export const getCustomWords = (language?: string): CustomWord[] => {
  try {
    const raw = localStorage.getItem(KEYS.CUSTOM_WORDS);
    const list: CustomWord[] = raw ? JSON.parse(raw) : [];
    return language ? list.filter((w) => w.language === language) : list;
  } catch {
    return [];
  }
};

export const addCustomWord = (word: CustomWord): boolean => {
  const english = word.english.trim();
  if (!english) return false;
  const list = getCustomWords();
  if (list.some((w) => w.language === word.language && w.english.toLowerCase() === english.toLowerCase())) {
    return false; // word exists
  }
  const updated = [{ ...word, english }, ...list];
  localStorage.setItem(KEYS.CUSTOM_WORDS, JSON.stringify(updated));
  return true;
};

export const removeCustomWord = (language: string, english: string): void => {
  const list = getCustomWords();
  const updated = list.filter(
    (w) => !(w.language === language && w.english.toLowerCase() === english.toLowerCase())
  );
  localStorage.setItem(KEYS.CUSTOM_WORDS, JSON.stringify(updated));
};

// Favorites
export const getFavorites = (): TranslationMessage[] => {
  try {
    const raw = localStorage.getItem(KEYS.FAVORITES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const toggleFavorite = (msg: TranslationMessage): boolean => {
  const favorites = getFavorites();
  const exists = favorites.some((f) => f.id === msg.id || (f.sourceText === msg.sourceText && f.translatedText === msg.translatedText));

  let updated: TranslationMessage[];
  if (exists) {
    updated = favorites.filter((f) => f.id !== msg.id && f.sourceText !== msg.sourceText);
  } else {
    updated = [{ ...msg, isFavorite: true }, ...favorites];
  }
  localStorage.setItem(KEYS.FAVORITES, JSON.stringify(updated));
  return !exists;
};

// History
export const getHistory = (): TranslationMessage[] => {
  try {
    const raw = localStorage.getItem(KEYS.HISTORY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveHistoryMessage = (msg: TranslationMessage): TranslationMessage[] => {
  const history = getHistory();
  const filtered = history.filter((h) => h.id !== msg.id);
  const updated = [msg, ...filtered].slice(0, 50); // limit 50 messages
  localStorage.setItem(KEYS.HISTORY, JSON.stringify(updated));
  return updated;
};

export const clearHistory = (): void => {
  localStorage.removeItem(KEYS.HISTORY);
};
