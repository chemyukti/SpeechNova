// Client-side offline translation dictionary and rule-based translation engine
// Designed for offline usage in PWA, browser offline mode, or Android Studio WebView export.

import {
  getTranslationFromCache,
  saveTranslationToCache,
  lookupLocalDictionary,
  seedInitialDictionary,
  IndexedDBDictionaryEntry,
} from "./indexedDB";

interface OfflineEntry {
  en: string;
  hi?: string;
  es?: string;
  fr?: string;
  de?: string;
  ja?: string;
  zh?: string;
  it?: string;
  ar?: string;
  ru?: string;
  ko?: string;
}

const COMMON_DICTIONARY: OfflineEntry[] = [
  { en: "hello", hi: "नमस्ते", es: "hola", fr: "bonjour", de: "hallo", ja: "こんにちは", zh: "你好", it: "ciao", ar: "مرحبا", ru: "здравствуйте", ko: "안녕하세요" },
  { en: "hi", hi: "नमस्ते", es: "hola", fr: "salut", de: "hallo", ja: "やあ", zh: "嗨", it: "ciao", ar: "مرحبا", ru: "привет", ko: "안녕" },
  { en: "good morning", hi: "सुप्रभात", es: "buenos días", fr: "bonjour", de: "guten Morgen", ja: "おはようございます", zh: "早安", it: "buongiorno", ar: "صباح الخير", ru: "доброе утро", ko: "좋은 아침" },
  { en: "good night", hi: "शुभ रात्रि", es: "buenas noches", fr: "bonne nuit", de: "gute Nacht", ja: "おやすみなさい", zh: "晚安", it: "buona notte", ar: "تصبح على خير", ru: "спокойной ночи", ko: "안녕히 주무세요" },
  { en: "thank you", hi: "धन्यवाद", es: "gracias", fr: "merci", de: "danke", ja: "ありがとうございます", zh: "谢谢", it: "grazie", ar: "شكرا لك", ru: "спасибо", ko: "감사합니다" },
  { en: "thanks", hi: "शुक्रिया", es: "gracias", fr: "merci", de: "danke", ja: "ありがとう", zh: "谢谢", it: "grazie", ar: "شكرا", ru: "спасибо", ko: "고마워" },
  { en: "how are you", hi: "आप कैसे हैं?", es: "¿cómo estás?", fr: "comment allez-vous?", de: "wie geht es dir?", ja: "お元気ですか？", zh: "你好吗？", it: "come stai?", ar: "كيف حالك؟", ru: "как дела?", ko: "어떻게 지내세요?" },
  { en: "where is the bathroom", hi: "शौचालय कहाँ है?", es: "¿dónde está el baño?", fr: "où sont les toilettes?", de: "wo ist die Toilette?", ja: "お手洗いはどこですか？", zh: "洗手间在哪里？", it: "dov'è il bagno?", ar: "أين الحمام؟", ru: "где туалет?", ko: "화장실이 어디예요?" },
  { en: "what is your name", hi: "आपका नाम क्या है?", es: "¿cómo te llamas?", fr: "comment vous appelez-vous?", de: "wie heißen Sie?", ja: "お名前は何ですか？", zh: "你叫什么名字？", it: "come ti chiami?", ar: "ما اسمك؟", ru: "как вас зовут?", ko: "이름이 무엇인가요?" },
  { en: "my name is", hi: "मेरा नाम है", es: "mi nombre es", fr: "je m'appelle", de: "mein Name ist", ja: "私の名前は", zh: "我的名字是", it: "il mio nome è", ar: "اسمي هو", ru: "меня зовут", ko: "제 이름은" },
  { en: "yes", hi: "हाँ", es: "sí", fr: "oui", de: "ja", ja: "はい", zh: "是", it: "sì", ar: "نعم", ru: "да", ko: "네" },
  { en: "no", hi: "नहीं", es: "no", fr: "non", de: "nein", ja: "いいえ", zh: "不", it: "no", ar: "لا", ru: "нет", ko: "아니요" },
  { en: "please", hi: "कृपया", es: "por favor", fr: "s'il vous plaît", de: "bitte", ja: "お願いします", zh: "请", it: "per favore", ar: "من فضلك", ru: "пожалуйста", ko: "부탁합니다" },
  { en: "sorry", hi: "माफ़ कीजिये", es: "lo siento", fr: "désolé", de: "entschuldigung", ja: "ごめんなさい", zh: "对不起", it: "scusa", ar: "آسف", ru: "извините", ko: "죄송합니다" },
  { en: "excuse me", hi: "क्षमा करें", es: "disculpe", fr: "excusez-moi", de: "entschuldigen Sie", ja: "すみません", zh: "抱歉", it: "scusi", ar: "عفوا", ru: "простите", ko: "실례합니다" },
  { en: "goodbye", hi: "अलविदा", es: "adiós", fr: "au revoir", de: "auf Wiedersehen", ja: "さようなら", zh: "再见", it: "arrivederci", ar: "مع السلامة", ru: "до свидания", ko: "안녕히 가세요" },
  { en: "i love you", hi: "मैं आपसे प्यार करता हूँ", es: "te amo", fr: "je t'aime", de: "ich liebe dich", ja: "愛しています", zh: "我爱你", it: "ti amo", ar: "أحبك", ru: "я люблю тебя", ko: "사랑해요" },
  { en: "help", hi: "मदद", es: "ayuda", fr: "aide", de: "Hilfe", ja: "助けて", zh: "帮助", it: "aiuto", ar: "مساعدة", ru: "помощь", ko: "도와주세요" },
  { en: "water", hi: "पानी", es: "agua", fr: "eau", de: "Wasser", ja: "水", zh: "水", it: "acqua", ar: "ماء", ru: "вода", ko: "물" },
  { en: "food", hi: "खाना", es: "comida", fr: "nourriture", de: "Essen", ja: "食べ物", zh: "食物", it: "cibo", ar: "طعام", ru: "еда", ko: "음식" },
  { en: "hospital", hi: "अस्पताल", es: "hospital", fr: "hôpital", de: "Krankenhaus", ja: "病院", zh: "医院", it: "ospedale", ar: "مستشفى", ru: "больница", ko: "병원" },
  { en: "how much is this", hi: "यह कितने का है?", es: "¿cuánto cuesta esto?", fr: "combien ça coûte?", de: "wie viel kostet das?", ja: "これはいくらですか？", zh: "这个多少钱？", it: "quanto costa questo?", ar: "بكم هذا؟", ru: "сколько это стоит?", ko: "이것은 얼마인가요?" }
];

const LANG_CODE_MAP: Record<string, keyof OfflineEntry> = {
  English: "en",
  Hindi: "hi",
  Spanish: "es",
  French: "fr",
  German: "de",
  Japanese: "ja",
  Chinese: "zh",
  Italian: "it",
  Arabic: "ar",
  Russian: "ru",
  Korean: "ko",
};

export function detectLanguageOffline(text: string): string {
  if (!text || !text.trim()) return "English";
  
  // 1. Script matching rules (Unicode range checks)
  if (/[\u0900-\u097F]/.test(text)) {
    // Devanagari script: could be Hindi or Marathi. Check for Marathi specific characters/words
    if (/[\u0933\u0934]/.test(text) || /\b(आहे|आणि|नाही|काय|होय)\b/i.test(text)) return "Marathi";
    return "Hindi";
  }
  if (/[\u0980-\u09FF]/.test(text)) return "Bengali";
  if (/[\u0B80-\u0BFF]/.test(text)) return "Tamil";
  if (/[\u0C00-\u0C7F]/.test(text)) return "Telugu";
  if (/[\u0A80-\u0AFF]/.test(text)) return "Gujarati";
  if (/[\u0C80-\u0CFF]/.test(text)) return "Kannada";
  if (/[\u0600-\u06FF\u0750-\u077F]/.test(text)) {
    if (/\b(ہے|تھا|آپ|کیا|تھے|ہی)\b/i.test(text)) return "Urdu";
    if (/\b(است|این|برای|که|در)\b/i.test(text)) return "Persian";
    return "Arabic";
  }
  if (/[\u3040-\u30FF\u31F0-\u31FF]/.test(text)) return "Japanese";
  if (/[\u4E00-\u9FFF]/.test(text)) return "Chinese";
  if (/[\uAC00-\uD7AF\u1100-\u11FF]/.test(text)) return "Korean";
  if (/[\u0400-\u04FF]/.test(text)) {
    if (/\b(привіт|дякую|є|та|що|як)\b/i.test(text)) return "Ukrainian";
    if (/\b(здравей|благодаря|е|на|за)\b/i.test(text)) return "Bulgarian";
    return "Russian";
  }
  if (/[\u0E00-\u0E7F]/.test(text)) return "Thai";
  if (/[\u0370-\u03FF]/.test(text)) return "Greek";
  if (/[\u0590-\u05FF]/.test(text)) return "Hebrew";

  // 2. Vocabulary & diacritics heuristics for Latin script languages
  const lower = text.toLowerCase().trim();
  
  if (/[ñ¿¡]/i.test(text) || /\b(hola|gracias|por favor|buenos|dias|estás|donde|como|que|sí)\b/i.test(lower)) return "Spanish";
  if (/[éèêëàâùûçœæ]/i.test(text) || /\b(bonjour|merci|comment|vous|avec|pour|s'il|plaît|oui)\b/i.test(lower)) return "French";
  if (/[äöüß]/i.test(text) || /\b(hallo|danke|guten|morgen|nicht|bitte|wie|geht|und)\b/i.test(lower)) return "German";
  if (/[àèéìíîòóùú]/i.test(text) || /\b(ciao|grazie|buongiorno|scusi|per|favore|come|stai)\b/i.test(lower)) return "Italian";
  if (/[ãõçáéíóúâêô]/i.test(text) || /\b(olá|obrigado|obrigada|por|favor|bom|dia|como|vai)\b/i.test(lower)) return "Portuguese";
  if (/[çğıöşü]/i.test(text) || /\b(merhaba|teşekkürler|lütfen|evet|hayır|nasılsın)\b/i.test(lower)) return "Turkish";
  if (/[đàáảãạèéẻẽẹìíỉĩịòóỏõọùúủũụ]/i.test(text) || /\b(xin|chào|cảm|ơn|vâng|không)\b/i.test(lower)) return "Vietnamese";
  if (/\b(hallo|dank|wel|alstublieft|hoe|gaat|het)\b/i.test(lower)) return "Dutch";
  if (/[ąćęłńóśźż]/i.test(text) || /\b(cześć|dziękuję|proszę|tak|nie|jak|się)\b/i.test(lower)) return "Polish";

  return "English";
}

export function sampleAndDetectLanguage(sampleText: string): {
  language: string;
  confidence: number;
} {
  const detected = detectLanguageOffline(sampleText);
  const confidence = detected !== "English" || /\b(the|is|and|you|hello|what|how)\b/i.test(sampleText) ? 0.95 : 0.70;
  return { language: detected, confidence };
}

export function translateOffline(
  text: string,
  sourceLang: string,
  targetLang: string
): { translatedText: string; detectedLanguage: string; romanization: string } {
  const cleanInput = text.trim();
  const inferredSource = sourceLang === "Auto Detect" ? detectLanguageOffline(cleanInput) : sourceLang;

  const srcKey = LANG_CODE_MAP[inferredSource] || "en";
  const tgtKey = LANG_CODE_MAP[targetLang] || "en";

  const lowerInput = cleanInput.toLowerCase();

  // 1. Direct phrase match in dictionary
  const exactMatch = COMMON_DICTIONARY.find((entry) => {
    const val = entry[srcKey];
    return val && val.toLowerCase() === lowerInput;
  });

  if (exactMatch && exactMatch[tgtKey]) {
    return {
      translatedText: exactMatch[tgtKey]!,
      detectedLanguage: inferredSource,
      romanization: tgtKey === "hi" ? "Phonetic reading" : "",
    };
  }

  // 2. Partial word-by-word token replacement fallback
  const words = cleanInput.split(/\s+/);
  const translatedWords = words.map((w) => {
    const cleanWord = w.toLowerCase().replace(/[^\w\u00C0-\u024F\u0900-\u097F\u3040-\u30FF\u4E00-\u9FFF]/g, "");
    const match = COMMON_DICTIONARY.find((entry) => entry[srcKey] && entry[srcKey]!.toLowerCase() === cleanWord);
    return match && match[tgtKey] ? match[tgtKey] : w;
  });

  const joined = translatedWords.join(" ");
  if (joined !== cleanInput) {
    return {
      translatedText: joined,
      detectedLanguage: inferredSource,
      romanization: "",
    };
  }

  // 3. Fallback translation format without extra bracket tags
  return {
    translatedText: cleanInput,
    detectedLanguage: inferredSource,
    romanization: "",
  };
}

let isIndexedDBSeeded = false;

// Initialize & seed IndexedDB dictionary asynchronously
export async function initIndexedDBDictionary(): Promise<void> {
  if (isIndexedDBSeeded || typeof window === "undefined") return;

  try {
    const seedEntries: Omit<IndexedDBDictionaryEntry, "id" | "timestamp">[] = [];
    const langNames = Object.keys(LANG_CODE_MAP);

    for (const entry of COMMON_DICTIONARY) {
      for (const srcLang of langNames) {
        const srcCode = LANG_CODE_MAP[srcLang];
        const srcText = entry[srcCode];
        if (!srcText) continue;

        for (const tgtLang of langNames) {
          if (srcLang === tgtLang) continue;
          const tgtCode = LANG_CODE_MAP[tgtLang];
          const tgtText = entry[tgtCode];
          if (!tgtText) continue;

          seedEntries.push({
            sourceLang: srcLang,
            targetLang: tgtLang,
            sourceText: srcText,
            translatedText: tgtText,
            romanization: tgtLang === "Hindi" ? "Phonetic reading" : "",
            category: "Essential Vocabulary",
          });
        }
      }
    }

    await seedInitialDictionary(seedEntries);
    isIndexedDBSeeded = true;
  } catch (err) {
    console.warn("IndexedDB dictionary auto-seed warning:", err);
  }
}

// Async IndexedDB-backed offline translation with caching and dictionary lookup
export async function translateOfflineAsync(
  text: string,
  sourceLang: string,
  targetLang: string
): Promise<{ translatedText: string; detectedLanguage: string; romanization: string; fromCache?: boolean; fromIndexedDBDict?: boolean }> {
  const cleanInput = text.trim();
  if (!cleanInput) {
    return { translatedText: "", detectedLanguage: sourceLang, romanization: "" };
  }

  const inferredSource = sourceLang === "Auto Detect" ? detectLanguageOffline(cleanInput) : sourceLang;

  // 1. Check IndexedDB Translation Cache first
  try {
    const cached = await getTranslationFromCache(inferredSource, targetLang, cleanInput);
    if (cached) {
      return {
        translatedText: cached.translatedText,
        detectedLanguage: cached.detectedLanguage || inferredSource,
        romanization: cached.romanization || "",
        fromCache: true,
      };
    }
  } catch (e) {
    // proceed to DB lookup
  }

  // 2. Check IndexedDB Dictionary store
  try {
    const dbDictEntry = await lookupLocalDictionary(inferredSource, targetLang, cleanInput);
    if (dbDictEntry) {
      const result = {
        translatedText: dbDictEntry.translatedText,
        detectedLanguage: inferredSource,
        romanization: dbDictEntry.romanization || "",
        fromIndexedDBDict: true,
      };
      // Save to cache for next time
      saveTranslationToCache({
        sourceLang: inferredSource,
        targetLang,
        sourceText: cleanInput,
        translatedText: result.translatedText,
        detectedLanguage: inferredSource,
        romanization: result.romanization,
      }).catch(() => {});
      return result;
    }
  } catch (e) {
    // proceed to rule translator
  }

  // 3. Fallback to synchronous dictionary & rule translator
  const result = translateOffline(cleanInput, sourceLang, targetLang);

  // Cache result into IndexedDB
  saveTranslationToCache({
    sourceLang: result.detectedLanguage || inferredSource,
    targetLang,
    sourceText: cleanInput,
    translatedText: result.translatedText,
    detectedLanguage: result.detectedLanguage || inferredSource,
    romanization: result.romanization,
  }).catch(() => {});

  return result;
}

