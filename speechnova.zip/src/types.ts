export interface Language {
  name: String;
  code: string; // ISO 2-letter or BCP-47 tag
  mlkitCode: string;
  speechTag: string; // Speech recognition tag (e.g., 'hi-IN')
  flag: string;
  hasScript?: boolean;
}

export interface TranslationMessage {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  timestamp: number;
  romanization?: string;
  isFavorite?: boolean;
  latencyMs?: number;
}

export interface PhraseCategory {
  id: string;
  name: string;
  iconName: string;
  phrases: Array<{
    id: string;
    english: string;
    translation?: string;
  }>;
}

export interface AlphabetItem {
  letter: string;
  name: string;
  sound: string;
  exampleWord: string;
  exampleTranslation: string;
}

export interface ScriptGroup {
  language: string;
  scriptName: string;
  description: string;
  letters: AlphabetItem[];
}

export interface VocabItem {
  id: string;
  english: string;
  category: string;
  translations: Record<string, string>; // lang -> translation
}

export interface QuizQuestion {
  id: string;
  englishWord: string;
  correctAnswer: string;
  options: string[];
  language: string;
}

export interface Learner {
  name: string;
  points: number;
}

export interface CustomWord {
  english: string;
  language: string;
  translated: string;
}

export interface AppSettings {
  speechSpeed: number; // 0.5 to 2.0
  speechVolume?: number; // 0.0 to 1.0
  speechPitch: number; // 0.5 to 1.5
  voiceGender: 'male' | 'female';
  ttsEngine?: 'auto' | 'natural_hd' | 'webspeech';
  selectedVoiceURI?: string;
  romanticTone: boolean;
  practiceMode: boolean;
  offlineTipDismissed: boolean;
  micSensitivity?: number; // 10 to 100 (% threshold / sensitivity)
}
