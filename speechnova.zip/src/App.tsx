import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Navigation, TabType } from "./components/Navigation";
import { HomeScreen } from "./components/HomeScreen";
import { LectureScreen } from "./components/LectureScreen";
import { LearnScreen } from "./components/LearnScreen";
import { PhrasesScreen } from "./components/PhrasesScreen";
import { FaceToFaceScreen } from "./components/FaceToFaceScreen";
import { QuizScreen } from "./components/QuizScreen";

import { SettingsModal } from "./components/Modals/SettingsModal";
import { ScanOCRModal } from "./components/Modals/ScanOCRModal";
import { TypePasteModal } from "./components/Modals/TypePasteModal";
import { FavoritesModal } from "./components/Modals/FavoritesModal";
import { HelpModal } from "./components/Modals/HelpModal";

import { AppSettings, TranslationMessage } from "./types";
import {
  getAppSettings,
  getFavorites,
  getHistory,
  saveHistoryMessage,
  clearHistory,
  toggleFavorite,
} from "./utils/storage";

export function App() {
  const [activeTab, setActiveTab] = useState<TabType>("home");
  const [sourceLang, setSourceLang] = useState<string>("English");
  const [targetLang, setTargetLang] = useState<string>("Hindi");

  const [settings, setSettings] = useState<AppSettings>(() => getAppSettings());
  const [history, setHistory] = useState<TranslationMessage[]>(() => getHistory());
  const [favorites, setFavorites] = useState<TranslationMessage[]>(() => getFavorites());

  // Modal states
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isTypePasteOpen, setIsTypePasteOpen] = useState(false);
  const [isScanOCROpen, setIsScanOCROpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleNewTranslation = (msg: TranslationMessage) => {
    const updatedHistory = saveHistoryMessage(msg);
    setHistory(updatedHistory);
  };

  const handleToggleFavorite = (msg: TranslationMessage) => {
    toggleFavorite(msg);
    setFavorites(getFavorites());
    setHistory(getHistory());
  };

  const handleClearHistory = () => {
    clearHistory();
    setHistory([]);
  };

  const handleSwapLanguages = () => {
    if (sourceLang === "Auto Detect") {
      setSourceLang(targetLang);
      setTargetLang(targetLang === "English" ? "Hindi" : "English");
    } else {
      const prevSource = sourceLang;
      setSourceLang(targetLang);
      setTargetLang(prevSource);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Header Bar */}
      <Header
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenTypePaste={() => setIsTypePasteOpen(true)}
        onOpenScanOCR={() => setIsScanOCROpen(true)}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenLectureModal={() => setActiveTab("lecture")}
        favoriteCount={favorites.length}
        sourceLang={sourceLang}
        targetLang={targetLang}
        onSwapLanguages={handleSwapLanguages}
      />

      {/* Main View Container */}
      <main className="flex-1 max-w-4xl mx-auto w-full">
        {activeTab === "home" && (
          <HomeScreen
            messages={history}
            onNewTranslation={handleNewTranslation}
            onClearHistory={handleClearHistory}
            onToggleFavorite={handleToggleFavorite}
            sourceLang={sourceLang}
            setSourceLang={setSourceLang}
            targetLang={targetLang}
            setTargetLang={setTargetLang}
            settings={settings}
            onOpenLectureModal={() => setActiveTab("lecture")}
          />
        )}

        {activeTab === "lecture" && (
          <LectureScreen
            sourceLang={sourceLang}
            setSourceLang={setSourceLang}
            targetLang={targetLang}
            setTargetLang={setTargetLang}
          />
        )}

        {activeTab === "learn" && <LearnScreen targetLang={targetLang} />}

        {activeTab === "phrases" && <PhrasesScreen targetLang={targetLang} />}

        {activeTab === "face2face" && (
          <FaceToFaceScreen sourceLang={sourceLang} targetLang={targetLang} />
        )}

        {activeTab === "quiz" && <QuizScreen targetLang={targetLang} />}
      </main>

      {/* Navigation Bottom Bar */}
      <Navigation activeTab={activeTab} onSelectTab={setActiveTab} />

      {/* Modals */}
      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />

      <TypePasteModal
        isOpen={isTypePasteOpen}
        onClose={() => setIsTypePasteOpen(false)}
        targetLang={targetLang}
      />

      <ScanOCRModal
        isOpen={isScanOCROpen}
        onClose={() => setIsScanOCROpen(false)}
        targetLang={targetLang}
      />

      <FavoritesModal
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={setSettings}
      />
    </div>
  );
}

export default App;
