import { ScriptGroup } from "../types";

export const ALPHABET_SCRIPTS: ScriptGroup[] = [
  {
    language: "Hindi",
    scriptName: "Devanagari (देवनागरी)",
    description: "The phonetic script used for Hindi, Marathi, and Sanskrit.",
    letters: [
      { letter: "अ", name: "a", sound: "Short 'a' as in cup", exampleWord: "अनार", exampleTranslation: "Pomegranate" },
      { letter: "आ", name: "aa", sound: "Long 'aa' as in father", exampleWord: "आम", exampleTranslation: "Mango" },
      { letter: "इ", name: "i", sound: "Short 'i' as in sit", exampleWord: "इमली", exampleTranslation: "Tamarind" },
      { letter: "ई", name: "ee", sound: "Long 'ee' as in feet", exampleWord: "ईख", exampleTranslation: "Sugarcane" },
      { letter: "उ", name: "u", sound: "Short 'u' as in put", exampleWord: "उल्लू", exampleTranslation: "Owl" },
      { letter: "ऊ", name: "oo", sound: "Long 'oo' as in moon", exampleWord: "ऊन", exampleTranslation: "Wool" },
      { letter: "क", name: "ka", sound: "Unvoiced velar stop 'k'", exampleWord: "कमल", exampleTranslation: "Lotus" },
      { letter: "ख", name: "kha", sound: "Aspirated 'kh'", exampleWord: "खरगोश", exampleTranslation: "Rabbit" },
      { letter: "ग", name: "ga", sound: "Voiced 'g' as in go", exampleWord: "गमला", exampleTranslation: "Flower pot" },
      { letter: "घ", name: "gha", sound: "Aspirated voiced 'gh'", exampleWord: "घर", exampleTranslation: "House" },
      { letter: "च", name: "cha", sound: "Unvoiced palatal 'ch'", exampleWord: "चम्मच", exampleTranslation: "Spoon" },
      { letter: "छ", name: "chha", sound: "Aspirated 'chh'", exampleWord: "छतरी", exampleTranslation: "Umbrella" },
      { letter: "ज", name: "ja", sound: "Voiced palatal 'j'", exampleWord: "जहाज", exampleTranslation: "Ship" },
      { letter: "झ", name: "jha", sound: "Aspirated 'jh'", exampleWord: "झंडा", exampleTranslation: "Flag" },
      { letter: "ट", name: "Ta", sound: "Retroflex 'T' (tongue curled back)", exampleWord: "टमाटर", exampleTranslation: "Tomato" },
      { letter: "त", name: "ta", sound: "Dental 't' (tongue on teeth)", exampleWord: "तरबूज", exampleTranslation: "Watermelon" },
      { letter: "न", name: "na", sound: "Dental 'n'", exampleWord: "नल", exampleTranslation: "Tap" },
      { letter: "प", name: "pa", sound: "Unvoiced bilabial 'p'", exampleWord: "पतंग", exampleTranslation: "Kite" },
      { letter: "फ", name: "pha", sound: "Aspirated 'ph'", exampleWord: "फल", exampleTranslation: "Fruit" },
      { letter: "ब", name: "ba", sound: "Voiced 'b'", exampleWord: "बस", exampleTranslation: "Bus" },
      { letter: "भ", name: "bha", sound: "Aspirated 'bh'", exampleWord: "भालू", exampleTranslation: "Bear" },
      { letter: "म", name: "ma", sound: "Nasal 'm'", exampleWord: "मछली", exampleTranslation: "Fish" },
      { letter: "र", name: "ra", sound: "Flapped 'r'", exampleWord: "रथ", exampleTranslation: "Chariot" },
      { letter: "स", name: "sa", sound: "Soft 's'", exampleWord: "सेब", exampleTranslation: "Apple" }
    ]
  },
  {
    language: "Bengali",
    scriptName: "Bengali Alphabet (বাংলা বর্ণমালা)",
    description: "East Indic script used for Bengali and Assamese.",
    letters: [
      { letter: "অ", name: "o", sound: "Rounded short 'o'", exampleWord: "অজগর", exampleTranslation: "Python" },
      { letter: "আ", name: "aa", sound: "Open 'aa'", exampleWord: "আম", exampleTranslation: "Mango" },
      { letter: "ই", name: "i", sound: "Short 'i'", exampleWord: "ইঁদুর", exampleTranslation: "Mouse" },
      { letter: "ঈ", name: "ee", sound: "Long 'ee'", exampleWord: "ঈগল", exampleTranslation: "Eagle" },
      { letter: "ক", name: "ka", sound: "Unvoiced velar 'k'", exampleWord: "কাক", exampleTranslation: "Crow" },
      { letter: "খ", name: "kha", sound: "Aspirated 'kh'", exampleWord: "খাতা", exampleTranslation: "Notebook" },
      { letter: "গ", name: "ga", sound: "Voiced 'g'", exampleWord: "গাড়ি", exampleTranslation: "Car" },
      { letter: "ঘ", name: "gha", sound: "Aspirated 'gh'", exampleWord: "ঘোড়া", exampleTranslation: "Horse" },
      { letter: "চ", name: "cha", sound: "Palatal 'ch'", exampleWord: "চাবি", exampleTranslation: "Key" },
      { letter: "ছ", name: "chha", sound: "Aspirated 'chh'", exampleWord: "ছাগল", exampleTranslation: "Goat" },
      { letter: "জ", name: "ja", sound: "Voiced 'j'", exampleWord: "জল", exampleTranslation: "Water" },
      { letter: "ত", name: "ta", sound: "Dental 't'", exampleWord: "তালা", exampleTranslation: "Lock" },
      { letter: "ন", name: "na", sound: "Dental 'n'", exampleWord: "নৌকা", exampleTranslation: "Boat" },
      { letter: "প", name: "pa", sound: "Unvoiced 'p'", exampleWord: "পাখি", exampleTranslation: "Bird" },
      { letter: "ম", name: "ma", sound: "Nasal 'm'", exampleWord: "মাছ", exampleTranslation: "Fish" }
    ]
  },
  {
    language: "Arabic",
    scriptName: "Arabic Alphabet (الأبجدية العربية)",
    description: "Right-to-left abjad used across the Arab world.",
    letters: [
      { letter: "أ", name: "Alif", sound: "Glottal stop / long 'aa'", exampleWord: "أسد", exampleTranslation: "Lion" },
      { letter: "ب", name: "Baa", sound: "Voiced 'b'", exampleWord: "بيت", exampleTranslation: "House" },
      { letter: "ت", name: "Taa", sound: "Dental 't'", exampleWord: "تفاح", exampleTranslation: "Apple" },
      { letter: "ث", name: "Thaa", sound: "Unvoiced 'th' as in think", exampleWord: "ثعلب", exampleTranslation: "Fox" },
      { letter: "ج", name: "Jeem", sound: "Soft 'j' or 'g'", exampleWord: "جمل", exampleTranslation: "Camel" },
      { letter: "ح", name: "Haa", sound: "Pharyngeal 'h'", exampleWord: "حليب", exampleTranslation: "Milk" },
      { letter: "خ", name: "Khaa", sound: "Rough 'kh' as in Bach", exampleWord: "خبز", exampleTranslation: "Bread" },
      { letter: "د", name: "Dal", sound: "Dental 'd'", exampleWord: "دراجة", exampleTranslation: "Bicycle" },
      { letter: "ر", name: "Raa", sound: "Rolled 'r'", exampleWord: "رجل", exampleTranslation: "Man" },
      { letter: "س", name: "Seen", sound: "Soft 's'", exampleWord: "سيارة", exampleTranslation: "Car" },
      { letter: "ش", name: "Sheen", sound: "'Sh' sound", exampleWord: "شمس", exampleTranslation: "Sun" },
      { letter: "م", name: "Meem", sound: "Nasal 'm'", exampleWord: "ماء", exampleTranslation: "Water" }
    ]
  },
  {
    language: "Japanese",
    scriptName: "Hiragana (ひらがな)",
    description: "Phonetic syllabary essential for native Japanese words.",
    letters: [
      { letter: "あ", name: "a", sound: "'a' as in father", exampleWord: "あめ", exampleTranslation: "Rain" },
      { letter: "い", name: "i", sound: "'i' as in machine", exampleWord: "いぬ", exampleTranslation: "Dog" },
      { letter: "う", name: "u", sound: "'u' as in flute", exampleWord: "うみ", exampleTranslation: "Sea" },
      { letter: "え", name: "e", sound: "'e' as in pet", exampleWord: "えき", exampleTranslation: "Station" },
      { letter: "お", name: "o", sound: "'o' as in solo", exampleWord: "おにぎり", exampleTranslation: "Rice ball" },
      { letter: "か", name: "ka", sound: "'k' + 'a'", exampleWord: "かさ", exampleTranslation: "Umbrella" },
      { letter: "き", name: "ki", sound: "'k' + 'i'", exampleWord: "きのこ", exampleTranslation: "Mushroom" },
      { letter: "く", name: "ku", sound: "'k' + 'u'", exampleWord: "くるま", exampleTranslation: "Car" },
      { letter: "け", name: "ke", sound: "'k' + 'e'", exampleWord: "けしごむ", exampleTranslation: "Eraser" },
      { letter: "こ", name: "ko", sound: "'k' + 'o'", exampleWord: "こども", exampleTranslation: "Child" },
      { letter: "さ", name: "sa", sound: "'s' + 'a'", exampleWord: "sakura", exampleTranslation: "Cherry blossom" },
      { letter: "た", name: "ta", sound: "'t' + 'a'", exampleWord: "たこ", exampleTranslation: "Octopus" },
      { letter: "な", name: "na", sound: "'n' + 'a'", exampleWord: "なつ", exampleTranslation: "Summer" },
      { letter: "は", name: "ha", sound: "'h' + 'a'", exampleWord: "はな", exampleTranslation: "Flower" },
      { letter: "ま", name: "ma", sound: "'m' + 'a'", exampleWord: "まち", exampleTranslation: "Town" }
    ]
  },
  {
    language: "Russian",
    scriptName: "Cyrillic Script (Кириллица)",
    description: "Slavic alphabet created by St. Cyril and Methodius.",
    letters: [
      { letter: "А", name: "A", sound: "'a' as in father", exampleWord: "Арбуз", exampleTranslation: "Watermelon" },
      { letter: "Б", name: "Be", sound: "'b' as in book", exampleWord: "Бабочка", exampleTranslation: "Butterfly" },
      { letter: "В", name: "Ve", sound: "'v' as in vine", exampleWord: "Вода", exampleTranslation: "Water" },
      { letter: "Г", name: "Ge", sound: "'g' as in go", exampleWord: "Гора", exampleTranslation: "Mountain" },
      { letter: "Д", name: "De", sound: "'d' as in door", exampleWord: "Дом", exampleTranslation: "House" },
      { letter: "Е", name: "Ye", sound: "'ye' as in yes", exampleWord: "Енот", exampleTranslation: "Raccoon" },
      { letter: "Ж", name: "Zhe", sound: "'zh' like pleasure", exampleWord: "Жук", exampleTranslation: "Beetle" },
      { letter: "З", name: "Ze", sound: "'z' as in zoo", exampleWord: "Звезда", exampleTranslation: "Star" },
      { letter: "И", name: "I", sound: "'ee' as in meet", exampleWord: "Игра", exampleTranslation: "Game" },
      { letter: "К", name: "Ka", sound: "'k' as in king", exampleWord: "Кот", exampleTranslation: "Cat" },
      { letter: "Л", name: "El", sound: "'l' as in lamp", exampleWord: "Луна", exampleTranslation: "Moon" },
      { letter: "М", name: "Em", sound: "'m' as in mother", exampleWord: "Молоко", exampleTranslation: "Milk" },
      { letter: "Н", name: "En", sound: "'n' as in net", exampleWord: "Небо", exampleTranslation: "Sky" },
      { letter: "О", name: "O", sound: "'o' as in born", exampleWord: "Окно", exampleTranslation: "Window" },
      { letter: "П", name: "Pe", sound: "'p' as in park", exampleWord: "Поезд", exampleTranslation: "Train" }
    ]
  },
  {
    language: "Greek",
    scriptName: "Greek Alphabet (Ελληνικό αλφάβητο)",
    description: "Classical alphabet used since late 9th century BC.",
    letters: [
      { letter: "Α", name: "Alpha", sound: "'a' sound", exampleWord: "Αστέρι", exampleTranslation: "Star" },
      { letter: "Β", name: "Beta", sound: "'v' sound", exampleWord: "Βιβλίο", exampleTranslation: "Book" },
      { letter: "Γ", name: "Gamma", sound: "Soft voiced 'g'", exampleWord: "Γάτα", exampleTranslation: "Cat" },
      { letter: "Δ", name: "Delta", sound: "'th' as in this", exampleWord: "Δέντρο", exampleTranslation: "Tree" },
      { letter: "Ε", name: "Epsilon", sound: "Short 'e'", exampleWord: "Ήλιος", exampleTranslation: "Sun" },
      { letter: "Ζ", name: "Zeta", sound: "'z' sound", exampleWord: "Ζωγραφιά", exampleTranslation: "Painting" },
      { letter: "Η", name: "Eta", sound: "'ee' sound", exampleWord: "Ήλιος", exampleTranslation: "Sun" },
      { letter: "Θ", name: "Theta", sound: "'th' as in think", exampleWord: "Θάλασσα", exampleTranslation: "Sea" },
      { letter: "Λ", name: "Lambda", sound: "'l' sound", exampleWord: "Λουλούδι", exampleTranslation: "Flower" },
      { letter: "Μ", name: "Mu", sound: "'m' sound", exampleWord: "Μήλο", exampleTranslation: "Apple" },
      { letter: "Ω", name: "Omega", sound: "Long 'o'", exampleWord: "Ώρα", exampleTranslation: "Hour" }
    ]
  }
];
