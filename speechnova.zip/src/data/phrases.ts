import { PhraseCategory } from "../types";

export const PHRASE_CATEGORIES: PhraseCategory[] = [
  {
    id: "daily",
    name: "Daily Expressions",
    iconName: "MessageCircle",
    phrases: [
      { id: "d1", english: "Hello! How are you?" },
      { id: "d2", english: "Thank you very much!" },
      { id: "d3", english: "You are welcome." },
      { id: "d4", english: "Excuse me / Pardon" },
      { id: "d5", english: "Nice to meet you." },
      { id: "d6", english: "Goodbye! Have a great day." },
      { id: "d7", english: "Yes, please." },
      { id: "d8", english: "No, thank you." },
      { id: "d9", english: "Do you speak English?" },
      { id: "d10", english: "I don't understand." },
      { id: "d11", english: "Please speak a bit slower." },
      { id: "d12", english: "Could you repeat that?" }
    ]
  },
  {
    id: "airport",
    name: "Airport & Travel",
    iconName: "Plane",
    phrases: [
      { id: "a1", english: "Where is the passport control?" },
      { id: "a2", english: "Here is my passport and ticket." },
      { id: "a3", english: "Where can I claim my baggage?" },
      { id: "a4", english: "Is this flight on time?" },
      { id: "a5", english: "Where is the boarding gate?" },
      { id: "a6", english: "I am traveling for vacation." },
      { id: "a7", english: "Where is the currency exchange?" },
      { id: "a8", english: "Where can I find a taxi?" }
    ]
  },
  {
    id: "restaurant",
    name: "Restaurant & Food",
    iconName: "Utensils",
    phrases: [
      { id: "r1", english: "A table for two, please." },
      { id: "r2", english: "Could we see the menu?" },
      { id: "r3", english: "What do you recommend?" },
      { id: "r4", english: "I would like a glass of water." },
      { id: "r5", english: "Is this dish vegetarian?" },
      { id: "r6", english: "The food is delicious!" },
      { id: "r7", english: "Could we have the bill, please?" },
      { id: "r8", english: "Do you accept credit cards?" }
    ]
  },
  {
    id: "hotel",
    name: "Accommodation",
    iconName: "Hotel",
    phrases: [
      { id: "h1", english: "I have a reservation under my name." },
      { id: "h2", english: "What time is check-in / check-out?" },
      { id: "h3", english: "Is Wi-Fi free in the room?" },
      { id: "h4", english: "What is the Wi-Fi password?" },
      { id: "h5", english: "Could I get extra towels, please?" },
      { id: "h6", english: "Where is breakfast served?" },
      { id: "h7", english: "Can you call a taxi for me?" }
    ]
  },
  {
    id: "transport",
    name: "Transportation",
    iconName: "Bus",
    phrases: [
      { id: "t1", english: "Where is the nearest subway station?" },
      { id: "t2", english: "How much is a ticket to the city center?" },
      { id: "t3", english: "Does this bus go to the airport?" },
      { id: "t4", english: "Please stop here." },
      { id: "t5", english: "Where can I buy a train ticket?" },
      { id: "t6", english: "How far is it on foot?" }
    ]
  },
  {
    id: "shopping",
    name: "Shopping & Money",
    iconName: "ShoppingBag",
    phrases: [
      { id: "s1", english: "How much does this cost?" },
      { id: "s2", english: "Can I try this on?" },
      { id: "s3", english: "Do you have this in a larger size?" },
      { id: "s4", english: "Is there a discount?" },
      { id: "s5", english: "I will take this one." },
      { id: "s6", english: "Where is the nearest ATM?" }
    ]
  },
  {
    id: "emergency",
    name: "Emergency & Health",
    iconName: "AlertTriangle",
    phrases: [
      { id: "e1", english: "Help! Please help me!" },
      { id: "e2", english: "I need a doctor urgently." },
      { id: "e3", english: "Call an ambulance!" },
      { id: "e4", english: "Where is the nearest hospital?" },
      { id: "e5", english: "I lost my passport." },
      { id: "e6", english: "I am feeling sick." },
      { id: "e7", english: "Where is the police station?" }
    ]
  }
];
