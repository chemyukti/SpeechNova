import { VocabItem } from "../types";

export const MASTER_VOCABULARY: VocabItem[] = [
  {
    id: "v1",
    english: "Water",
    category: "Basics",
    translations: {
      Hindi: "पानी (Paani)",
      Spanish: "Agua",
      French: "Eau",
      German: "Wasser",
      Bengali: "জল (Jol)",
      Japanese: "水 (Mizu)",
      Arabic: "ماء (Maa)",
      Russian: "Вода (Voda)"
    }
  },
  {
    id: "v2",
    english: "Food",
    category: "Basics",
    translations: {
      Hindi: "खाना (Khaana)",
      Spanish: "Comida",
      French: "Nourriture",
      German: "Essen",
      Bengali: "খাবার (Khabar)",
      Japanese: "食べ物 (Tabemono)",
      Arabic: "طعام (Ta'am)",
      Russian: "Еда (Yeda)"
    }
  },
  {
    id: "v3",
    english: "House / Home",
    category: "Basics",
    translations: {
      Hindi: "घर (Ghar)",
      Spanish: "Casa",
      French: "Maison",
      German: "Haus",
      Bengali: "বাড়ি (Bari)",
      Japanese: "家 (Ie)",
      Arabic: "بيت (Bayt)",
      Russian: "Дом (Dom)"
    }
  },
  {
    id: "v4",
    english: "Friend",
    category: "People",
    translations: {
      Hindi: "दोस्त (Dost)",
      Spanish: "Amigo",
      French: "Ami",
      German: "Freund",
      Bengali: "বন্ধু (Bondhu)",
      Japanese: "友達 (Tomodachi)",
      Arabic: "صديق (Sadiq)",
      Russian: "Друг (Drug)"
    }
  },
  {
    id: "v5",
    english: "Book",
    category: "Education",
    translations: {
      Hindi: "किताब (Kitaab)",
      Spanish: "Libro",
      French: "Livre",
      German: "Buch",
      Bengali: "বই (Boi)",
      Japanese: "本 (Hon)",
      Arabic: "كتاب (Kitab)",
      Russian: "Книга (Kniga)"
    }
  },
  {
    id: "v6",
    english: "Sun",
    category: "Nature",
    translations: {
      Hindi: "सूरज (Sooraj)",
      Spanish: "Sol",
      French: "Soleil",
      German: "Sonne",
      Bengali: "সূর্য (Surjo)",
      Japanese: "太陽 (Taiyou)",
      Arabic: "شمس (Shams)",
      Russian: "Солнце (Solntse)"
    }
  },
  {
    id: "v7",
    english: "Moon",
    category: "Nature",
    translations: {
      Hindi: "चाँद (Chaand)",
      Spanish: "Luna",
      French: "Lune",
      German: "Mond",
      Bengali: "চাঁদ (Chaand)",
      Japanese: "月 (Tsuki)",
      Arabic: "قمر (Qamar)",
      Russian: "Луна (Luna)"
    }
  },
  {
    id: "v8",
    english: "Flower",
    category: "Nature",
    translations: {
      Hindi: "फूल (Phool)",
      Spanish: "Flor",
      French: "Fleur",
      German: "Blume",
      Bengali: "ফুল (Phool)",
      Japanese: "花 (Hana)",
      Arabic: "زهرة (Zahra)",
      Russian: "Цветок (Tsvetok)"
    }
  },
  {
    id: "v9",
    english: "Time",
    category: "Abstract",
    translations: {
      Hindi: "समय (Samay)",
      Spanish: "Tiempo",
      French: "Temps",
      German: "Zeit",
      Bengali: "সময় (Somoy)",
      Japanese: "時間 (Jikan)",
      Arabic: "وقت (Waqt)",
      Russian: "Время (Vremya)"
    }
  },
  {
    id: "v10",
    english: "Love",
    category: "Emotions",
    translations: {
      Hindi: "प्यार (Pyaar)",
      Spanish: "Amor",
      French: "Amour",
      German: "Liebe",
      Bengali: "ভালোবাসা (Bhalobasha)",
      Japanese: "愛 (Ai)",
      Arabic: "حب (Hubb)",
      Russian: "Любовь (Lyubov)"
    }
  }
];
